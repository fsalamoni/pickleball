import{o as ni}from"./vendor-C0Jp-cV_.js";const Nr=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const si=function(n){const e=[];let i=0;for(let o=0;o<n.length;o++){let a=n.charCodeAt(o);a<128?e[i++]=a:a<2048?(e[i++]=a>>6|192,e[i++]=a&63|128):(a&64512)===55296&&o+1<n.length&&(n.charCodeAt(o+1)&64512)===56320?(a=65536+((a&1023)<<10)+(n.charCodeAt(++o)&1023),e[i++]=a>>18|240,e[i++]=a>>12&63|128,e[i++]=a>>6&63|128,e[i++]=a&63|128):(e[i++]=a>>12|224,e[i++]=a>>6&63|128,e[i++]=a&63|128)}return e},xr=function(n){const e=[];let i=0,o=0;for(;i<n.length;){const a=n[i++];if(a<128)e[o++]=String.fromCharCode(a);else if(a>191&&a<224){const h=n[i++];e[o++]=String.fromCharCode((a&31)<<6|h&63)}else if(a>239&&a<365){const h=n[i++],c=n[i++],w=n[i++],v=((a&7)<<18|(h&63)<<12|(c&63)<<6|w&63)-65536;e[o++]=String.fromCharCode(55296+(v>>10)),e[o++]=String.fromCharCode(56320+(v&1023))}else{const h=n[i++],c=n[i++];e[o++]=String.fromCharCode((a&15)<<12|(h&63)<<6|c&63)}}return e.join("")},ii={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const i=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,o=[];for(let a=0;a<n.length;a+=3){const h=n[a],c=a+1<n.length,w=c?n[a+1]:0,v=a+2<n.length,T=v?n[a+2]:0,S=h>>2,I=(h&3)<<4|w>>4;let C=(w&15)<<2|T>>6,O=T&63;v||(O=64,c||(C=64)),o.push(i[S],i[I],i[C],i[O])}return o.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(si(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):xr(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const i=e?this.charToByteMapWebSafe_:this.charToByteMap_,o=[];for(let a=0;a<n.length;){const h=i[n.charAt(a++)],w=a<n.length?i[n.charAt(a)]:0;++a;const T=a<n.length?i[n.charAt(a)]:64;++a;const I=a<n.length?i[n.charAt(a)]:64;if(++a,h==null||w==null||T==null||I==null)throw new Ur;const C=h<<2|w>>4;if(o.push(C),T!==64){const O=w<<4&240|T>>2;if(o.push(O),I!==64){const k=T<<6&192|I;o.push(k)}}}return o},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class Ur extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Mr=function(n){const e=si(n);return ii.encodeByteArray(e,!0)},Ie=function(n){return Mr(n).replace(/\./g,"")},Lr=function(n){try{return ii.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Br(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jr=()=>Br().__FIREBASE_DEFAULTS__,Fr=()=>{if(typeof process>"u"||typeof Ps>"u")return;const n=Ps.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},$r=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&Lr(n[1]);return e&&JSON.parse(e)},Ce=()=>{try{return Nr()||jr()||Fr()||$r()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},Hr=n=>{var e,i;return(i=(e=Ce())==null?void 0:e.emulatorHosts)==null?void 0:i[n]},zr=n=>{const e=Hr(n);if(!e)return;const i=e.lastIndexOf(":");if(i<=0||i+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const o=parseInt(e.substring(i+1),10);return e[0]==="["?[e.substring(1,i-1),o]:[e.substring(0,i),o]},ri=()=>{var n;return(n=Ce())==null?void 0:n.config},Yh=n=>{var e;return(e=Ce())==null?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qr{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,i)=>{this.resolve=e,this.reject=i})}wrapCallback(e){return(i,o)=>{i?this.reject(i):this.resolve(o),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(i):e(i,o))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vr(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const i={alg:"none",type:"JWT"},o=e||"demo-project",a=n.iat||0,h=n.sub||n.user_id;if(!h)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const c={iss:`https://securetoken.google.com/${o}`,aud:o,iat:a,exp:a+3600,auth_time:a,sub:h,user_id:h,firebase:{sign_in_provider:"custom",identities:{}},...n};return[Ie(JSON.stringify(i)),Ie(JSON.stringify(c)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oi(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Jh(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(oi())}function Gr(){var e;const n=(e=Ce())==null?void 0:e.forceEnvironment;if(n==="node")return!0;if(n==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function Zh(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function Wr(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function Qh(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function tc(){const n=oi();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function ec(){return!Gr()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function ai(){try{return typeof indexedDB=="object"}catch{return!1}}function li(){return new Promise((n,e)=>{try{let i=!0;const o="validate-browser-context-for-indexeddb-analytics-module",a=self.indexedDB.open(o);a.onsuccess=()=>{a.result.close(),i||self.indexedDB.deleteDatabase(o),n(!0)},a.onupgradeneeded=()=>{i=!1},a.onerror=()=>{var h;e(((h=a.error)==null?void 0:h.message)||"")}}catch(i){e(i)}})}function Xr(){return!(typeof navigator>"u"||!navigator.cookieEnabled)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kr="FirebaseError";class _t extends Error{constructor(e,i,o){super(i),this.code=e,this.customData=o,this.name=Kr,Object.setPrototypeOf(this,_t.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,ke.prototype.create)}}class ke{constructor(e,i,o){this.service=e,this.serviceName=i,this.errors=o}create(e,...i){const o=i[0]||{},a=`${this.service}/${e}`,h=this.errors[e],c=h?Yr(h,o):"Error",w=`${this.serviceName}: ${c} (${a}).`;return new _t(a,w,o)}}function Yr(n,e){return n.replace(Jr,(i,o)=>{const a=e[o];return a!=null?String(a):`<${o}?>`})}const Jr=/\{\$([^}]+)}/g;function nc(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function fn(n,e){if(n===e)return!0;const i=Object.keys(n),o=Object.keys(e);for(const a of i){if(!o.includes(a))return!1;const h=n[a],c=e[a];if(Ns(h)&&Ns(c)){if(!fn(h,c))return!1}else if(h!==c)return!1}for(const a of o)if(!i.includes(a))return!1;return!0}function Ns(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sc(n){const e=[];for(const[i,o]of Object.entries(n))Array.isArray(o)?o.forEach(a=>{e.push(encodeURIComponent(i)+"="+encodeURIComponent(a))}):e.push(encodeURIComponent(i)+"="+encodeURIComponent(o));return e.length?"&"+e.join("&"):""}function ic(n){const e={};return n.replace(/^\?/,"").split("&").forEach(o=>{if(o){const[a,h]=o.split("=");e[decodeURIComponent(a)]=decodeURIComponent(h)}}),e}function rc(n){const e=n.indexOf("?");if(!e)return"";const i=n.indexOf("#",e);return n.substring(e,i>0?i:void 0)}function oc(n,e){const i=new Zr(n,e);return i.subscribe.bind(i)}class Zr{constructor(e,i){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=i,this.task.then(()=>{e(this)}).catch(o=>{this.error(o)})}next(e){this.forEachObserver(i=>{i.next(e)})}error(e){this.forEachObserver(i=>{i.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,i,o){let a;if(e===void 0&&i===void 0&&o===void 0)throw new Error("Missing Observer.");Qr(e,["next","error","complete"])?a=e:a={next:e,error:i,complete:o},a.next===void 0&&(a.next=sn),a.error===void 0&&(a.error=sn),a.complete===void 0&&(a.complete=sn);const h=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?a.error(this.finalError):a.complete()}catch{}}),this.observers.push(a),h}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let i=0;i<this.observers.length;i++)this.sendOne(i,e)}sendOne(e,i){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{i(this.observers[e])}catch(o){typeof console<"u"&&console.error&&console.error(o)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function Qr(n,e){if(typeof n!="object"||n===null)return!1;for(const i of e)if(i in n&&typeof n[i]=="function")return!0;return!1}function sn(){}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const to=1e3,eo=2,no=14400*1e3,so=.5;function xs(n,e=to,i=eo){const o=e*Math.pow(i,n),a=Math.round(so*o*(Math.random()-.5)*2);return Math.min(no,o+a)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pt(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hi(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function io(n){return(await fetch(n,{credentials:"include"})).ok}class at{constructor(e,i,o){this.name=e,this.instanceFactory=i,this.type=o,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const St="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ro{constructor(e,i){this.name=e,this.container=i,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const i=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(i)){const o=new qr;if(this.instancesDeferred.set(i,o),this.isInitialized(i)||this.shouldAutoInitialize())try{const a=this.getOrInitializeService({instanceIdentifier:i});a&&o.resolve(a)}catch{}}return this.instancesDeferred.get(i).promise}getImmediate(e){const i=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),o=(e==null?void 0:e.optional)??!1;if(this.isInitialized(i)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:i})}catch(a){if(o)return null;throw a}else{if(o)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(ao(e))try{this.getOrInitializeService({instanceIdentifier:St})}catch{}for(const[i,o]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(i);try{const h=this.getOrInitializeService({instanceIdentifier:a});o.resolve(h)}catch{}}}}clearInstance(e=St){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(i=>"INTERNAL"in i).map(i=>i.INTERNAL.delete()),...e.filter(i=>"_delete"in i).map(i=>i._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=St){return this.instances.has(e)}getOptions(e=St){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:i={}}=e,o=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(o))throw Error(`${this.name}(${o}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const a=this.getOrInitializeService({instanceIdentifier:o,options:i});for(const[h,c]of this.instancesDeferred.entries()){const w=this.normalizeInstanceIdentifier(h);o===w&&c.resolve(a)}return a}onInit(e,i){const o=this.normalizeInstanceIdentifier(i),a=this.onInitCallbacks.get(o)??new Set;a.add(e),this.onInitCallbacks.set(o,a);const h=this.instances.get(o);return h&&e(h,o),()=>{a.delete(e)}}invokeOnInitCallbacks(e,i){const o=this.onInitCallbacks.get(i);if(o)for(const a of o)try{a(e,i)}catch{}}getOrInitializeService({instanceIdentifier:e,options:i={}}){let o=this.instances.get(e);if(!o&&this.component&&(o=this.component.instanceFactory(this.container,{instanceIdentifier:oo(e),options:i}),this.instances.set(e,o),this.instancesOptions.set(e,i),this.invokeOnInitCallbacks(o,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,o)}catch{}return o||null}normalizeInstanceIdentifier(e=St){return this.component?this.component.multipleInstances?e:St:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function oo(n){return n===St?void 0:n}function ao(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lo{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const i=this.getProvider(e.name);if(i.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);i.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const i=new ro(e,this);return this.providers.set(e,i),i}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var U;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(U||(U={}));const ho={debug:U.DEBUG,verbose:U.VERBOSE,info:U.INFO,warn:U.WARN,error:U.ERROR,silent:U.SILENT},co=U.INFO,uo={[U.DEBUG]:"log",[U.VERBOSE]:"log",[U.INFO]:"info",[U.WARN]:"warn",[U.ERROR]:"error"},fo=(n,e,...i)=>{if(e<n.logLevel)return;const o=new Date().toISOString(),a=uo[e];if(a)console[a](`[${o}]  ${n.name}:`,...i);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class ci{constructor(e){this.name=e,this._logLevel=co,this._logHandler=fo,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in U))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?ho[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,U.DEBUG,...e),this._logHandler(this,U.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,U.VERBOSE,...e),this._logHandler(this,U.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,U.INFO,...e),this._logHandler(this,U.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,U.WARN,...e),this._logHandler(this,U.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,U.ERROR,...e),this._logHandler(this,U.ERROR,...e)}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class po{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(i=>{if(go(i)){const o=i.getImmediate();return`${o.library}/${o.version}`}else return null}).filter(i=>i).join(" ")}}function go(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const dn="@firebase/app",Us="0.14.11";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lt=new ci("@firebase/app"),mo="@firebase/app-compat",yo="@firebase/analytics-compat",_o="@firebase/analytics",bo="@firebase/app-check-compat",wo="@firebase/app-check",vo="@firebase/auth",To="@firebase/auth-compat",Eo="@firebase/database",Io="@firebase/data-connect",So="@firebase/database-compat",Ao="@firebase/functions",Ro="@firebase/functions-compat",Co="@firebase/installations",ko="@firebase/installations-compat",Oo="@firebase/messaging",Do="@firebase/messaging-compat",Po="@firebase/performance",No="@firebase/performance-compat",xo="@firebase/remote-config",Uo="@firebase/remote-config-compat",Mo="@firebase/storage",Lo="@firebase/storage-compat",Bo="@firebase/firestore",jo="@firebase/ai",Fo="@firebase/firestore-compat",$o="firebase",Ho="12.12.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pn="[DEFAULT]",zo={[dn]:"fire-core",[mo]:"fire-core-compat",[_o]:"fire-analytics",[yo]:"fire-analytics-compat",[wo]:"fire-app-check",[bo]:"fire-app-check-compat",[vo]:"fire-auth",[To]:"fire-auth-compat",[Eo]:"fire-rtdb",[Io]:"fire-data-connect",[So]:"fire-rtdb-compat",[Ao]:"fire-fn",[Ro]:"fire-fn-compat",[Co]:"fire-iid",[ko]:"fire-iid-compat",[Oo]:"fire-fcm",[Do]:"fire-fcm-compat",[Po]:"fire-perf",[No]:"fire-perf-compat",[xo]:"fire-rc",[Uo]:"fire-rc-compat",[Mo]:"fire-gcs",[Lo]:"fire-gcs-compat",[Bo]:"fire-fst",[Fo]:"fire-fst-compat",[jo]:"fire-vertex","fire-js":"fire-js",[$o]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Se=new Map,qo=new Map,gn=new Map;function Ms(n,e){try{n.container.addComponent(e)}catch(i){lt.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,i)}}function yt(n){const e=n.name;if(gn.has(e))return lt.debug(`There were multiple attempts to register component ${e}.`),!1;gn.set(e,n);for(const i of Se.values())Ms(i,n);for(const i of qo.values())Ms(i,n);return!0}function _n(n,e){const i=n.container.getProvider("heartbeat").getImmediate({optional:!0});return i&&i.triggerHeartbeat(),n.container.getProvider(e)}function Vo(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Go={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},mt=new ke("app","Firebase",Go);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wo{constructor(e,i,o){this._isDeleted=!1,this._options={...e},this._config={...i},this._name=i.name,this._automaticDataCollectionEnabled=i.automaticDataCollectionEnabled,this._container=o,this.container.addComponent(new at("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw mt.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xo=Ho;function Ko(n,e={}){let i=n;typeof e!="object"&&(e={name:e});const o={name:pn,automaticDataCollectionEnabled:!0,...e},a=o.name;if(typeof a!="string"||!a)throw mt.create("bad-app-name",{appName:String(a)});if(i||(i=ri()),!i)throw mt.create("no-options");const h=Se.get(a);if(h){if(fn(i,h.options)&&fn(o,h.config))return h;throw mt.create("duplicate-app",{appName:a})}const c=new lo(a);for(const v of gn.values())c.addComponent(v);const w=new Wo(i,o,c);return Se.set(a,w),w}function Yo(n=pn){const e=Se.get(n);if(!e&&n===pn&&ri())return Ko();if(!e)throw mt.create("no-app",{appName:n});return e}function rt(n,e,i){let o=zo[n]??n;i&&(o+=`-${i}`);const a=o.match(/\s|\//),h=e.match(/\s|\//);if(a||h){const c=[`Unable to register library "${o}" with version "${e}":`];a&&c.push(`library name "${o}" contains illegal characters (whitespace or "/")`),a&&h&&c.push("and"),h&&c.push(`version name "${e}" contains illegal characters (whitespace or "/")`),lt.warn(c.join(" "));return}yt(new at(`${o}-version`,()=>({library:o,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jo="firebase-heartbeat-database",Zo=1,ie="firebase-heartbeat-store";let rn=null;function ui(){return rn||(rn=ni(Jo,Zo,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(ie)}catch(i){console.warn(i)}}}}).catch(n=>{throw mt.create("idb-open",{originalErrorMessage:n.message})})),rn}async function Qo(n){try{const i=(await ui()).transaction(ie),o=await i.objectStore(ie).get(fi(n));return await i.done,o}catch(e){if(e instanceof _t)lt.warn(e.message);else{const i=mt.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});lt.warn(i.message)}}}async function Ls(n,e){try{const o=(await ui()).transaction(ie,"readwrite");await o.objectStore(ie).put(e,fi(n)),await o.done}catch(i){if(i instanceof _t)lt.warn(i.message);else{const o=mt.create("idb-set",{originalErrorMessage:i==null?void 0:i.message});lt.warn(o.message)}}}function fi(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ta=1024,ea=30;class na{constructor(e){this.container=e,this._heartbeatsCache=null;const i=this.container.getProvider("app").getImmediate();this._storage=new ia(i),this._heartbeatsCachePromise=this._storage.read().then(o=>(this._heartbeatsCache=o,o))}async triggerHeartbeat(){var e,i;try{const a=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),h=Bs();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((i=this._heartbeatsCache)==null?void 0:i.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===h||this._heartbeatsCache.heartbeats.some(c=>c.date===h))return;if(this._heartbeatsCache.heartbeats.push({date:h,agent:a}),this._heartbeatsCache.heartbeats.length>ea){const c=ra(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(c,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(o){lt.warn(o)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const i=Bs(),{heartbeatsToSend:o,unsentEntries:a}=sa(this._heartbeatsCache.heartbeats),h=Ie(JSON.stringify({version:2,heartbeats:o}));return this._heartbeatsCache.lastSentHeartbeatDate=i,a.length>0?(this._heartbeatsCache.heartbeats=a,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),h}catch(i){return lt.warn(i),""}}}function Bs(){return new Date().toISOString().substring(0,10)}function sa(n,e=ta){const i=[];let o=n.slice();for(const a of n){const h=i.find(c=>c.agent===a.agent);if(h){if(h.dates.push(a.date),js(i)>e){h.dates.pop();break}}else if(i.push({agent:a.agent,dates:[a.date]}),js(i)>e){i.pop();break}o=o.slice(1)}return{heartbeatsToSend:i,unsentEntries:o}}class ia{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return ai()?li().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const i=await Qo(this.app);return i!=null&&i.heartbeats?i:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const o=await this.read();return Ls(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??o.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const o=await this.read();return Ls(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??o.lastSentHeartbeatDate,heartbeats:[...o.heartbeats,...e.heartbeats]})}else return}}function js(n){return Ie(JSON.stringify({version:2,heartbeats:n})).length}function ra(n){if(n.length===0)return-1;let e=0,i=n[0].date;for(let o=1;o<n.length;o++)n[o].date<i&&(i=n[o].date,e=o);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oa(n){yt(new at("platform-logger",e=>new po(e),"PRIVATE")),yt(new at("heartbeat",e=>new na(e),"PRIVATE")),rt(dn,Us,n),rt(dn,Us,"esm2020"),rt("fire-js","")}oa("");var Fs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var aa,la;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(g,u){function d(){}d.prototype=u.prototype,g.F=u.prototype,g.prototype=new d,g.prototype.constructor=g,g.D=function(m,p,_){for(var f=Array(arguments.length-2),J=2;J<arguments.length;J++)f[J-2]=arguments[J];return u.prototype[p].apply(m,f)}}function i(){this.blockSize=-1}function o(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(o,i),o.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function a(g,u,d){d||(d=0);const m=Array(16);if(typeof u=="string")for(var p=0;p<16;++p)m[p]=u.charCodeAt(d++)|u.charCodeAt(d++)<<8|u.charCodeAt(d++)<<16|u.charCodeAt(d++)<<24;else for(p=0;p<16;++p)m[p]=u[d++]|u[d++]<<8|u[d++]<<16|u[d++]<<24;u=g.g[0],d=g.g[1],p=g.g[2];let _=g.g[3],f;f=u+(_^d&(p^_))+m[0]+3614090360&4294967295,u=d+(f<<7&4294967295|f>>>25),f=_+(p^u&(d^p))+m[1]+3905402710&4294967295,_=u+(f<<12&4294967295|f>>>20),f=p+(d^_&(u^d))+m[2]+606105819&4294967295,p=_+(f<<17&4294967295|f>>>15),f=d+(u^p&(_^u))+m[3]+3250441966&4294967295,d=p+(f<<22&4294967295|f>>>10),f=u+(_^d&(p^_))+m[4]+4118548399&4294967295,u=d+(f<<7&4294967295|f>>>25),f=_+(p^u&(d^p))+m[5]+1200080426&4294967295,_=u+(f<<12&4294967295|f>>>20),f=p+(d^_&(u^d))+m[6]+2821735955&4294967295,p=_+(f<<17&4294967295|f>>>15),f=d+(u^p&(_^u))+m[7]+4249261313&4294967295,d=p+(f<<22&4294967295|f>>>10),f=u+(_^d&(p^_))+m[8]+1770035416&4294967295,u=d+(f<<7&4294967295|f>>>25),f=_+(p^u&(d^p))+m[9]+2336552879&4294967295,_=u+(f<<12&4294967295|f>>>20),f=p+(d^_&(u^d))+m[10]+4294925233&4294967295,p=_+(f<<17&4294967295|f>>>15),f=d+(u^p&(_^u))+m[11]+2304563134&4294967295,d=p+(f<<22&4294967295|f>>>10),f=u+(_^d&(p^_))+m[12]+1804603682&4294967295,u=d+(f<<7&4294967295|f>>>25),f=_+(p^u&(d^p))+m[13]+4254626195&4294967295,_=u+(f<<12&4294967295|f>>>20),f=p+(d^_&(u^d))+m[14]+2792965006&4294967295,p=_+(f<<17&4294967295|f>>>15),f=d+(u^p&(_^u))+m[15]+1236535329&4294967295,d=p+(f<<22&4294967295|f>>>10),f=u+(p^_&(d^p))+m[1]+4129170786&4294967295,u=d+(f<<5&4294967295|f>>>27),f=_+(d^p&(u^d))+m[6]+3225465664&4294967295,_=u+(f<<9&4294967295|f>>>23),f=p+(u^d&(_^u))+m[11]+643717713&4294967295,p=_+(f<<14&4294967295|f>>>18),f=d+(_^u&(p^_))+m[0]+3921069994&4294967295,d=p+(f<<20&4294967295|f>>>12),f=u+(p^_&(d^p))+m[5]+3593408605&4294967295,u=d+(f<<5&4294967295|f>>>27),f=_+(d^p&(u^d))+m[10]+38016083&4294967295,_=u+(f<<9&4294967295|f>>>23),f=p+(u^d&(_^u))+m[15]+3634488961&4294967295,p=_+(f<<14&4294967295|f>>>18),f=d+(_^u&(p^_))+m[4]+3889429448&4294967295,d=p+(f<<20&4294967295|f>>>12),f=u+(p^_&(d^p))+m[9]+568446438&4294967295,u=d+(f<<5&4294967295|f>>>27),f=_+(d^p&(u^d))+m[14]+3275163606&4294967295,_=u+(f<<9&4294967295|f>>>23),f=p+(u^d&(_^u))+m[3]+4107603335&4294967295,p=_+(f<<14&4294967295|f>>>18),f=d+(_^u&(p^_))+m[8]+1163531501&4294967295,d=p+(f<<20&4294967295|f>>>12),f=u+(p^_&(d^p))+m[13]+2850285829&4294967295,u=d+(f<<5&4294967295|f>>>27),f=_+(d^p&(u^d))+m[2]+4243563512&4294967295,_=u+(f<<9&4294967295|f>>>23),f=p+(u^d&(_^u))+m[7]+1735328473&4294967295,p=_+(f<<14&4294967295|f>>>18),f=d+(_^u&(p^_))+m[12]+2368359562&4294967295,d=p+(f<<20&4294967295|f>>>12),f=u+(d^p^_)+m[5]+4294588738&4294967295,u=d+(f<<4&4294967295|f>>>28),f=_+(u^d^p)+m[8]+2272392833&4294967295,_=u+(f<<11&4294967295|f>>>21),f=p+(_^u^d)+m[11]+1839030562&4294967295,p=_+(f<<16&4294967295|f>>>16),f=d+(p^_^u)+m[14]+4259657740&4294967295,d=p+(f<<23&4294967295|f>>>9),f=u+(d^p^_)+m[1]+2763975236&4294967295,u=d+(f<<4&4294967295|f>>>28),f=_+(u^d^p)+m[4]+1272893353&4294967295,_=u+(f<<11&4294967295|f>>>21),f=p+(_^u^d)+m[7]+4139469664&4294967295,p=_+(f<<16&4294967295|f>>>16),f=d+(p^_^u)+m[10]+3200236656&4294967295,d=p+(f<<23&4294967295|f>>>9),f=u+(d^p^_)+m[13]+681279174&4294967295,u=d+(f<<4&4294967295|f>>>28),f=_+(u^d^p)+m[0]+3936430074&4294967295,_=u+(f<<11&4294967295|f>>>21),f=p+(_^u^d)+m[3]+3572445317&4294967295,p=_+(f<<16&4294967295|f>>>16),f=d+(p^_^u)+m[6]+76029189&4294967295,d=p+(f<<23&4294967295|f>>>9),f=u+(d^p^_)+m[9]+3654602809&4294967295,u=d+(f<<4&4294967295|f>>>28),f=_+(u^d^p)+m[12]+3873151461&4294967295,_=u+(f<<11&4294967295|f>>>21),f=p+(_^u^d)+m[15]+530742520&4294967295,p=_+(f<<16&4294967295|f>>>16),f=d+(p^_^u)+m[2]+3299628645&4294967295,d=p+(f<<23&4294967295|f>>>9),f=u+(p^(d|~_))+m[0]+4096336452&4294967295,u=d+(f<<6&4294967295|f>>>26),f=_+(d^(u|~p))+m[7]+1126891415&4294967295,_=u+(f<<10&4294967295|f>>>22),f=p+(u^(_|~d))+m[14]+2878612391&4294967295,p=_+(f<<15&4294967295|f>>>17),f=d+(_^(p|~u))+m[5]+4237533241&4294967295,d=p+(f<<21&4294967295|f>>>11),f=u+(p^(d|~_))+m[12]+1700485571&4294967295,u=d+(f<<6&4294967295|f>>>26),f=_+(d^(u|~p))+m[3]+2399980690&4294967295,_=u+(f<<10&4294967295|f>>>22),f=p+(u^(_|~d))+m[10]+4293915773&4294967295,p=_+(f<<15&4294967295|f>>>17),f=d+(_^(p|~u))+m[1]+2240044497&4294967295,d=p+(f<<21&4294967295|f>>>11),f=u+(p^(d|~_))+m[8]+1873313359&4294967295,u=d+(f<<6&4294967295|f>>>26),f=_+(d^(u|~p))+m[15]+4264355552&4294967295,_=u+(f<<10&4294967295|f>>>22),f=p+(u^(_|~d))+m[6]+2734768916&4294967295,p=_+(f<<15&4294967295|f>>>17),f=d+(_^(p|~u))+m[13]+1309151649&4294967295,d=p+(f<<21&4294967295|f>>>11),f=u+(p^(d|~_))+m[4]+4149444226&4294967295,u=d+(f<<6&4294967295|f>>>26),f=_+(d^(u|~p))+m[11]+3174756917&4294967295,_=u+(f<<10&4294967295|f>>>22),f=p+(u^(_|~d))+m[2]+718787259&4294967295,p=_+(f<<15&4294967295|f>>>17),f=d+(_^(p|~u))+m[9]+3951481745&4294967295,g.g[0]=g.g[0]+u&4294967295,g.g[1]=g.g[1]+(p+(f<<21&4294967295|f>>>11))&4294967295,g.g[2]=g.g[2]+p&4294967295,g.g[3]=g.g[3]+_&4294967295}o.prototype.v=function(g,u){u===void 0&&(u=g.length);const d=u-this.blockSize,m=this.C;let p=this.h,_=0;for(;_<u;){if(p==0)for(;_<=d;)a(this,g,_),_+=this.blockSize;if(typeof g=="string"){for(;_<u;)if(m[p++]=g.charCodeAt(_++),p==this.blockSize){a(this,m),p=0;break}}else for(;_<u;)if(m[p++]=g[_++],p==this.blockSize){a(this,m),p=0;break}}this.h=p,this.o+=u},o.prototype.A=function(){var g=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);g[0]=128;for(var u=1;u<g.length-8;++u)g[u]=0;u=this.o*8;for(var d=g.length-8;d<g.length;++d)g[d]=u&255,u/=256;for(this.v(g),g=Array(16),u=0,d=0;d<4;++d)for(let m=0;m<32;m+=8)g[u++]=this.g[d]>>>m&255;return g};function h(g,u){var d=w;return Object.prototype.hasOwnProperty.call(d,g)?d[g]:d[g]=u(g)}function c(g,u){this.h=u;const d=[];let m=!0;for(let p=g.length-1;p>=0;p--){const _=g[p]|0;m&&_==u||(d[p]=_,m=!1)}this.g=d}var w={};function v(g){return-128<=g&&g<128?h(g,function(u){return new c([u|0],u<0?-1:0)}):new c([g|0],g<0?-1:0)}function T(g){if(isNaN(g)||!isFinite(g))return I;if(g<0)return A(T(-g));const u=[];let d=1;for(let m=0;g>=d;m++)u[m]=g/d|0,d*=4294967296;return new c(u,0)}function S(g,u){if(g.length==0)throw Error("number format error: empty string");if(u=u||10,u<2||36<u)throw Error("radix out of range: "+u);if(g.charAt(0)=="-")return A(S(g.substring(1),u));if(g.indexOf("-")>=0)throw Error('number format error: interior "-" character');const d=T(Math.pow(u,8));let m=I;for(let _=0;_<g.length;_+=8){var p=Math.min(8,g.length-_);const f=parseInt(g.substring(_,_+p),u);p<8?(p=T(Math.pow(u,p)),m=m.j(p).add(T(f))):(m=m.j(d),m=m.add(T(f)))}return m}var I=v(0),C=v(1),O=v(16777216);n=c.prototype,n.m=function(){if(D(this))return-A(this).m();let g=0,u=1;for(let d=0;d<this.g.length;d++){const m=this.i(d);g+=(m>=0?m:4294967296+m)*u,u*=4294967296}return g},n.toString=function(g){if(g=g||10,g<2||36<g)throw Error("radix out of range: "+g);if(k(this))return"0";if(D(this))return"-"+A(this).toString(g);const u=T(Math.pow(g,6));var d=this;let m="";for(;;){const p=L(d,u).g;d=z(d,p.j(u));let _=((d.g.length>0?d.g[0]:d.h)>>>0).toString(g);if(d=p,k(d))return _+m;for(;_.length<6;)_="0"+_;m=_+m}},n.i=function(g){return g<0?0:g<this.g.length?this.g[g]:this.h};function k(g){if(g.h!=0)return!1;for(let u=0;u<g.g.length;u++)if(g.g[u]!=0)return!1;return!0}function D(g){return g.h==-1}n.l=function(g){return g=z(this,g),D(g)?-1:k(g)?0:1};function A(g){const u=g.g.length,d=[];for(let m=0;m<u;m++)d[m]=~g.g[m];return new c(d,~g.h).add(C)}n.abs=function(){return D(this)?A(this):this},n.add=function(g){const u=Math.max(this.g.length,g.g.length),d=[];let m=0;for(let p=0;p<=u;p++){let _=m+(this.i(p)&65535)+(g.i(p)&65535),f=(_>>>16)+(this.i(p)>>>16)+(g.i(p)>>>16);m=f>>>16,_&=65535,f&=65535,d[p]=f<<16|_}return new c(d,d[d.length-1]&-2147483648?-1:0)};function z(g,u){return g.add(A(u))}n.j=function(g){if(k(this)||k(g))return I;if(D(this))return D(g)?A(this).j(A(g)):A(A(this).j(g));if(D(g))return A(this.j(A(g)));if(this.l(O)<0&&g.l(O)<0)return T(this.m()*g.m());const u=this.g.length+g.g.length,d=[];for(var m=0;m<2*u;m++)d[m]=0;for(m=0;m<this.g.length;m++)for(let p=0;p<g.g.length;p++){const _=this.i(m)>>>16,f=this.i(m)&65535,J=g.i(p)>>>16,bt=g.i(p)&65535;d[2*m+2*p]+=f*bt,q(d,2*m+2*p),d[2*m+2*p+1]+=_*bt,q(d,2*m+2*p+1),d[2*m+2*p+1]+=f*J,q(d,2*m+2*p+1),d[2*m+2*p+2]+=_*J,q(d,2*m+2*p+2)}for(g=0;g<u;g++)d[g]=d[2*g+1]<<16|d[2*g];for(g=u;g<2*u;g++)d[g]=0;return new c(d,0)};function q(g,u){for(;(g[u]&65535)!=g[u];)g[u+1]+=g[u]>>>16,g[u]&=65535,u++}function N(g,u){this.g=g,this.h=u}function L(g,u){if(k(u))throw Error("division by zero");if(k(g))return new N(I,I);if(D(g))return u=L(A(g),u),new N(A(u.g),A(u.h));if(D(u))return u=L(g,A(u)),new N(A(u.g),u.h);if(g.g.length>30){if(D(g)||D(u))throw Error("slowDivide_ only works with positive integers.");for(var d=C,m=u;m.l(g)<=0;)d=G(d),m=G(m);var p=F(d,1),_=F(m,1);for(m=F(m,2),d=F(d,2);!k(m);){var f=_.add(m);f.l(g)<=0&&(p=p.add(d),_=f),m=F(m,1),d=F(d,1)}return u=z(g,p.j(u)),new N(p,u)}for(p=I;g.l(u)>=0;){for(d=Math.max(1,Math.floor(g.m()/u.m())),m=Math.ceil(Math.log(d)/Math.LN2),m=m<=48?1:Math.pow(2,m-48),_=T(d),f=_.j(u);D(f)||f.l(g)>0;)d-=m,_=T(d),f=_.j(u);k(_)&&(_=C),p=p.add(_),g=z(g,f)}return new N(p,g)}n.B=function(g){return L(this,g).h},n.and=function(g){const u=Math.max(this.g.length,g.g.length),d=[];for(let m=0;m<u;m++)d[m]=this.i(m)&g.i(m);return new c(d,this.h&g.h)},n.or=function(g){const u=Math.max(this.g.length,g.g.length),d=[];for(let m=0;m<u;m++)d[m]=this.i(m)|g.i(m);return new c(d,this.h|g.h)},n.xor=function(g){const u=Math.max(this.g.length,g.g.length),d=[];for(let m=0;m<u;m++)d[m]=this.i(m)^g.i(m);return new c(d,this.h^g.h)};function G(g){const u=g.g.length+1,d=[];for(let m=0;m<u;m++)d[m]=g.i(m)<<1|g.i(m-1)>>>31;return new c(d,g.h)}function F(g,u){const d=u>>5;u%=32;const m=g.g.length-d,p=[];for(let _=0;_<m;_++)p[_]=u>0?g.i(_+d)>>>u|g.i(_+d+1)<<32-u:g.i(_+d);return new c(p,g.h)}o.prototype.digest=o.prototype.A,o.prototype.reset=o.prototype.u,o.prototype.update=o.prototype.v,la=o,c.prototype.add=c.prototype.add,c.prototype.multiply=c.prototype.j,c.prototype.modulo=c.prototype.B,c.prototype.compare=c.prototype.l,c.prototype.toNumber=c.prototype.m,c.prototype.toString=c.prototype.toString,c.prototype.getBits=c.prototype.i,c.fromNumber=T,c.fromString=S,aa=c}).apply(typeof Fs<"u"?Fs:typeof self<"u"?self:typeof window<"u"?window:{});var ve=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var ha,ca,ua,fa,da,pa,ga,ma;(function(){var n,e=Object.defineProperty;function i(t){t=[typeof globalThis=="object"&&globalThis,t,typeof window=="object"&&window,typeof self=="object"&&self,typeof ve=="object"&&ve];for(var s=0;s<t.length;++s){var r=t[s];if(r&&r.Math==Math)return r}throw Error("Cannot find global object")}var o=i(this);function a(t,s){if(s)t:{var r=o;t=t.split(".");for(var l=0;l<t.length-1;l++){var y=t[l];if(!(y in r))break t;r=r[y]}t=t[t.length-1],l=r[t],s=s(l),s!=l&&s!=null&&e(r,t,{configurable:!0,writable:!0,value:s})}}a("Symbol.dispose",function(t){return t||Symbol("Symbol.dispose")}),a("Array.prototype.values",function(t){return t||function(){return this[Symbol.iterator]()}}),a("Object.entries",function(t){return t||function(s){var r=[],l;for(l in s)Object.prototype.hasOwnProperty.call(s,l)&&r.push([l,s[l]]);return r}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var h=h||{},c=this||self;function w(t){var s=typeof t;return s=="object"&&t!=null||s=="function"}function v(t,s,r){return t.call.apply(t.bind,arguments)}function T(t,s,r){return T=v,T.apply(null,arguments)}function S(t,s){var r=Array.prototype.slice.call(arguments,1);return function(){var l=r.slice();return l.push.apply(l,arguments),t.apply(this,l)}}function I(t,s){function r(){}r.prototype=s.prototype,t.Z=s.prototype,t.prototype=new r,t.prototype.constructor=t,t.Ob=function(l,y,b){for(var E=Array(arguments.length-2),R=2;R<arguments.length;R++)E[R-2]=arguments[R];return s.prototype[y].apply(l,E)}}var C=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?t=>t&&AsyncContext.Snapshot.wrap(t):t=>t;function O(t){const s=t.length;if(s>0){const r=Array(s);for(let l=0;l<s;l++)r[l]=t[l];return r}return[]}function k(t,s){for(let l=1;l<arguments.length;l++){const y=arguments[l];var r=typeof y;if(r=r!="object"?r:y?Array.isArray(y)?"array":r:"null",r=="array"||r=="object"&&typeof y.length=="number"){r=t.length||0;const b=y.length||0;t.length=r+b;for(let E=0;E<b;E++)t[r+E]=y[E]}else t.push(y)}}class D{constructor(s,r){this.i=s,this.j=r,this.h=0,this.g=null}get(){let s;return this.h>0?(this.h--,s=this.g,this.g=s.next,s.next=null):s=this.i(),s}}function A(t){c.setTimeout(()=>{throw t},0)}function z(){var t=g;let s=null;return t.g&&(s=t.g,t.g=t.g.next,t.g||(t.h=null),s.next=null),s}class q{constructor(){this.h=this.g=null}add(s,r){const l=N.get();l.set(s,r),this.h?this.h.next=l:this.g=l,this.h=l}}var N=new D(()=>new L,t=>t.reset());class L{constructor(){this.next=this.g=this.h=null}set(s,r){this.h=s,this.g=r,this.next=null}reset(){this.next=this.g=this.h=null}}let G,F=!1,g=new q,u=()=>{const t=Promise.resolve(void 0);G=()=>{t.then(d)}};function d(){for(var t;t=z();){try{t.h.call(t.g)}catch(r){A(r)}var s=N;s.j(t),s.h<100&&(s.h++,t.next=s.g,s.g=t)}F=!1}function m(){this.u=this.u,this.C=this.C}m.prototype.u=!1,m.prototype.dispose=function(){this.u||(this.u=!0,this.N())},m.prototype[Symbol.dispose]=function(){this.dispose()},m.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function p(t,s){this.type=t,this.g=this.target=s,this.defaultPrevented=!1}p.prototype.h=function(){this.defaultPrevented=!0};var _=(function(){if(!c.addEventListener||!Object.defineProperty)return!1;var t=!1,s=Object.defineProperty({},"passive",{get:function(){t=!0}});try{const r=()=>{};c.addEventListener("test",r,s),c.removeEventListener("test",r,s)}catch{}return t})();function f(t){return/^[\s\xa0]*$/.test(t)}function J(t,s){p.call(this,t?t.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,t&&this.init(t,s)}I(J,p),J.prototype.init=function(t,s){const r=this.type=t.type,l=t.changedTouches&&t.changedTouches.length?t.changedTouches[0]:null;this.target=t.target||t.srcElement,this.g=s,s=t.relatedTarget,s||(r=="mouseover"?s=t.fromElement:r=="mouseout"&&(s=t.toElement)),this.relatedTarget=s,l?(this.clientX=l.clientX!==void 0?l.clientX:l.pageX,this.clientY=l.clientY!==void 0?l.clientY:l.pageY,this.screenX=l.screenX||0,this.screenY=l.screenY||0):(this.clientX=t.clientX!==void 0?t.clientX:t.pageX,this.clientY=t.clientY!==void 0?t.clientY:t.pageY,this.screenX=t.screenX||0,this.screenY=t.screenY||0),this.button=t.button,this.key=t.key||"",this.ctrlKey=t.ctrlKey,this.altKey=t.altKey,this.shiftKey=t.shiftKey,this.metaKey=t.metaKey,this.pointerId=t.pointerId||0,this.pointerType=t.pointerType,this.state=t.state,this.i=t,t.defaultPrevented&&J.Z.h.call(this)},J.prototype.h=function(){J.Z.h.call(this);const t=this.i;t.preventDefault?t.preventDefault():t.returnValue=!1};var bt="closure_listenable_"+(Math.random()*1e6|0),er=0;function nr(t,s,r,l,y){this.listener=t,this.proxy=null,this.src=s,this.type=r,this.capture=!!l,this.ha=y,this.key=++er,this.da=this.fa=!1}function oe(t){t.da=!0,t.listener=null,t.proxy=null,t.src=null,t.ha=null}function ae(t,s,r){for(const l in t)s.call(r,t[l],l,t)}function sr(t,s){for(const r in t)s.call(void 0,t[r],r,t)}function Dn(t){const s={};for(const r in t)s[r]=t[r];return s}const Pn="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function Nn(t,s){let r,l;for(let y=1;y<arguments.length;y++){l=arguments[y];for(r in l)t[r]=l[r];for(let b=0;b<Pn.length;b++)r=Pn[b],Object.prototype.hasOwnProperty.call(l,r)&&(t[r]=l[r])}}function le(t){this.src=t,this.g={},this.h=0}le.prototype.add=function(t,s,r,l,y){const b=t.toString();t=this.g[b],t||(t=this.g[b]=[],this.h++);const E=xe(t,s,l,y);return E>-1?(s=t[E],r||(s.fa=!1)):(s=new nr(s,this.src,b,!!l,y),s.fa=r,t.push(s)),s};function Ne(t,s){const r=s.type;if(r in t.g){var l=t.g[r],y=Array.prototype.indexOf.call(l,s,void 0),b;(b=y>=0)&&Array.prototype.splice.call(l,y,1),b&&(oe(s),t.g[r].length==0&&(delete t.g[r],t.h--))}}function xe(t,s,r,l){for(let y=0;y<t.length;++y){const b=t[y];if(!b.da&&b.listener==s&&b.capture==!!r&&b.ha==l)return y}return-1}var Ue="closure_lm_"+(Math.random()*1e6|0),Me={};function xn(t,s,r,l,y){if(Array.isArray(s)){for(let b=0;b<s.length;b++)xn(t,s[b],r,l,y);return null}return r=Ln(r),t&&t[bt]?t.J(s,r,w(l)?!!l.capture:!1,y):ir(t,s,r,!1,l,y)}function ir(t,s,r,l,y,b){if(!s)throw Error("Invalid event type");const E=w(y)?!!y.capture:!!y;let R=Be(t);if(R||(t[Ue]=R=new le(t)),r=R.add(s,r,l,E,b),r.proxy)return r;if(l=rr(),r.proxy=l,l.src=t,l.listener=r,t.addEventListener)_||(y=E),y===void 0&&(y=!1),t.addEventListener(s.toString(),l,y);else if(t.attachEvent)t.attachEvent(Mn(s.toString()),l);else if(t.addListener&&t.removeListener)t.addListener(l);else throw Error("addEventListener and attachEvent are unavailable.");return r}function rr(){function t(r){return s.call(t.src,t.listener,r)}const s=or;return t}function Un(t,s,r,l,y){if(Array.isArray(s))for(var b=0;b<s.length;b++)Un(t,s[b],r,l,y);else l=w(l)?!!l.capture:!!l,r=Ln(r),t&&t[bt]?(t=t.i,b=String(s).toString(),b in t.g&&(s=t.g[b],r=xe(s,r,l,y),r>-1&&(oe(s[r]),Array.prototype.splice.call(s,r,1),s.length==0&&(delete t.g[b],t.h--)))):t&&(t=Be(t))&&(s=t.g[s.toString()],t=-1,s&&(t=xe(s,r,l,y)),(r=t>-1?s[t]:null)&&Le(r))}function Le(t){if(typeof t!="number"&&t&&!t.da){var s=t.src;if(s&&s[bt])Ne(s.i,t);else{var r=t.type,l=t.proxy;s.removeEventListener?s.removeEventListener(r,l,t.capture):s.detachEvent?s.detachEvent(Mn(r),l):s.addListener&&s.removeListener&&s.removeListener(l),(r=Be(s))?(Ne(r,t),r.h==0&&(r.src=null,s[Ue]=null)):oe(t)}}}function Mn(t){return t in Me?Me[t]:Me[t]="on"+t}function or(t,s){if(t.da)t=!0;else{s=new J(s,this);const r=t.listener,l=t.ha||t.src;t.fa&&Le(t),t=r.call(l,s)}return t}function Be(t){return t=t[Ue],t instanceof le?t:null}var je="__closure_events_fn_"+(Math.random()*1e9>>>0);function Ln(t){return typeof t=="function"?t:(t[je]||(t[je]=function(s){return t.handleEvent(s)}),t[je])}function V(){m.call(this),this.i=new le(this),this.M=this,this.G=null}I(V,m),V.prototype[bt]=!0,V.prototype.removeEventListener=function(t,s,r,l){Un(this,t,s,r,l)};function W(t,s){var r,l=t.G;if(l)for(r=[];l;l=l.G)r.push(l);if(t=t.M,l=s.type||s,typeof s=="string")s=new p(s,t);else if(s instanceof p)s.target=s.target||t;else{var y=s;s=new p(l,t),Nn(s,y)}y=!0;let b,E;if(r)for(E=r.length-1;E>=0;E--)b=s.g=r[E],y=he(b,l,!0,s)&&y;if(b=s.g=t,y=he(b,l,!0,s)&&y,y=he(b,l,!1,s)&&y,r)for(E=0;E<r.length;E++)b=s.g=r[E],y=he(b,l,!1,s)&&y}V.prototype.N=function(){if(V.Z.N.call(this),this.i){var t=this.i;for(const s in t.g){const r=t.g[s];for(let l=0;l<r.length;l++)oe(r[l]);delete t.g[s],t.h--}}this.G=null},V.prototype.J=function(t,s,r,l){return this.i.add(String(t),s,!1,r,l)},V.prototype.K=function(t,s,r,l){return this.i.add(String(t),s,!0,r,l)};function he(t,s,r,l){if(s=t.i.g[String(s)],!s)return!0;s=s.concat();let y=!0;for(let b=0;b<s.length;++b){const E=s[b];if(E&&!E.da&&E.capture==r){const R=E.listener,$=E.ha||E.src;E.fa&&Ne(t.i,E),y=R.call($,l)!==!1&&y}}return y&&!l.defaultPrevented}function ar(t,s){if(typeof t!="function")if(t&&typeof t.handleEvent=="function")t=T(t.handleEvent,t);else throw Error("Invalid listener argument");return Number(s)>2147483647?-1:c.setTimeout(t,s||0)}function Bn(t){t.g=ar(()=>{t.g=null,t.i&&(t.i=!1,Bn(t))},t.l);const s=t.h;t.h=null,t.m.apply(null,s)}class lr extends m{constructor(s,r){super(),this.m=s,this.l=r,this.h=null,this.i=!1,this.g=null}j(s){this.h=arguments,this.g?this.i=!0:Bn(this)}N(){super.N(),this.g&&(c.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Ft(t){m.call(this),this.h=t,this.g={}}I(Ft,m);var jn=[];function Fn(t){ae(t.g,function(s,r){this.g.hasOwnProperty(r)&&Le(s)},t),t.g={}}Ft.prototype.N=function(){Ft.Z.N.call(this),Fn(this)},Ft.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Fe=c.JSON.stringify,hr=c.JSON.parse,cr=class{stringify(t){return c.JSON.stringify(t,void 0)}parse(t){return c.JSON.parse(t,void 0)}};function $n(){}function Hn(){}var $t={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function $e(){p.call(this,"d")}I($e,p);function He(){p.call(this,"c")}I(He,p);var wt={},zn=null;function ce(){return zn=zn||new V}wt.Ia="serverreachability";function qn(t){p.call(this,wt.Ia,t)}I(qn,p);function Ht(t){const s=ce();W(s,new qn(s))}wt.STAT_EVENT="statevent";function Vn(t,s){p.call(this,wt.STAT_EVENT,t),this.stat=s}I(Vn,p);function X(t){const s=ce();W(s,new Vn(s,t))}wt.Ja="timingevent";function Gn(t,s){p.call(this,wt.Ja,t),this.size=s}I(Gn,p);function zt(t,s){if(typeof t!="function")throw Error("Fn must not be null and must be a function");return c.setTimeout(function(){t()},s)}function qt(){this.g=!0}qt.prototype.ua=function(){this.g=!1};function ur(t,s,r,l,y,b){t.info(function(){if(t.g)if(b){var E="",R=b.split("&");for(let P=0;P<R.length;P++){var $=R[P].split("=");if($.length>1){const H=$[0];$=$[1];const st=H.split("_");E=st.length>=2&&st[1]=="type"?E+(H+"="+$+"&"):E+(H+"=redacted&")}}}else E=null;else E=b;return"XMLHTTP REQ ("+l+") [attempt "+y+"]: "+s+`
`+r+`
`+E})}function fr(t,s,r,l,y,b,E){t.info(function(){return"XMLHTTP RESP ("+l+") [ attempt "+y+"]: "+s+`
`+r+`
`+b+" "+E})}function xt(t,s,r,l){t.info(function(){return"XMLHTTP TEXT ("+s+"): "+pr(t,r)+(l?" "+l:"")})}function dr(t,s){t.info(function(){return"TIMEOUT: "+s})}qt.prototype.info=function(){};function pr(t,s){if(!t.g)return s;if(!s)return null;try{const b=JSON.parse(s);if(b){for(t=0;t<b.length;t++)if(Array.isArray(b[t])){var r=b[t];if(!(r.length<2)){var l=r[1];if(Array.isArray(l)&&!(l.length<1)){var y=l[0];if(y!="noop"&&y!="stop"&&y!="close")for(let E=1;E<l.length;E++)l[E]=""}}}}return Fe(b)}catch{return s}}var ue={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Wn={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},Xn;function ze(){}I(ze,$n),ze.prototype.g=function(){return new XMLHttpRequest},Xn=new ze;function Vt(t){return encodeURIComponent(String(t))}function gr(t){var s=1;t=t.split(":");const r=[];for(;s>0&&t.length;)r.push(t.shift()),s--;return t.length&&r.push(t.join(":")),r}function ht(t,s,r,l){this.j=t,this.i=s,this.l=r,this.S=l||1,this.V=new Ft(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Kn}function Kn(){this.i=null,this.g="",this.h=!1}var Yn={},qe={};function Ve(t,s,r){t.M=1,t.A=de(nt(s)),t.u=r,t.R=!0,Jn(t,null)}function Jn(t,s){t.F=Date.now(),fe(t),t.B=nt(t.A);var r=t.B,l=t.S;Array.isArray(l)||(l=[String(l)]),cs(r.i,"t",l),t.C=0,r=t.j.L,t.h=new Kn,t.g=Cs(t.j,r?s:null,!t.u),t.P>0&&(t.O=new lr(T(t.Y,t,t.g),t.P)),s=t.V,r=t.g,l=t.ba;var y="readystatechange";Array.isArray(y)||(y&&(jn[0]=y.toString()),y=jn);for(let b=0;b<y.length;b++){const E=xn(r,y[b],l||s.handleEvent,!1,s.h||s);if(!E)break;s.g[E.key]=E}s=t.J?Dn(t.J):{},t.u?(t.v||(t.v="POST"),s["Content-Type"]="application/x-www-form-urlencoded",t.g.ea(t.B,t.v,t.u,s)):(t.v="GET",t.g.ea(t.B,t.v,null,s)),Ht(),ur(t.i,t.v,t.B,t.l,t.S,t.u)}ht.prototype.ba=function(t){t=t.target;const s=this.O;s&&ft(t)==3?s.j():this.Y(t)},ht.prototype.Y=function(t){try{if(t==this.g)t:{const R=ft(this.g),$=this.g.ya(),P=this.g.ca();if(!(R<3)&&(R!=3||this.g&&(this.h.h||this.g.la()||ys(this.g)))){this.K||R!=4||$==7||($==8||P<=0?Ht(3):Ht(2)),Ge(this);var s=this.g.ca();this.X=s;var r=mr(this);if(this.o=s==200,fr(this.i,this.v,this.B,this.l,this.S,R,s),this.o){if(this.U&&!this.L){e:{if(this.g){var l,y=this.g;if((l=y.g?y.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!f(l)){var b=l;break e}}b=null}if(t=b)xt(this.i,this.l,t,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,We(this,t);else{this.o=!1,this.m=3,X(12),vt(this),Gt(this);break t}}if(this.R){t=!0;let H;for(;!this.K&&this.C<r.length;)if(H=yr(this,r),H==qe){R==4&&(this.m=4,X(14),t=!1),xt(this.i,this.l,null,"[Incomplete Response]");break}else if(H==Yn){this.m=4,X(15),xt(this.i,this.l,r,"[Invalid Chunk]"),t=!1;break}else xt(this.i,this.l,H,null),We(this,H);if(Zn(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),R!=4||r.length!=0||this.h.h||(this.m=1,X(16),t=!1),this.o=this.o&&t,!t)xt(this.i,this.l,r,"[Invalid Chunked Response]"),vt(this),Gt(this);else if(r.length>0&&!this.W){this.W=!0;var E=this.j;E.g==this&&E.aa&&!E.P&&(E.j.info("Great, no buffering proxy detected. Bytes received: "+r.length),en(E),E.P=!0,X(11))}}else xt(this.i,this.l,r,null),We(this,r);R==4&&vt(this),this.o&&!this.K&&(R==4?Is(this.j,this):(this.o=!1,fe(this)))}else Dr(this.g),s==400&&r.indexOf("Unknown SID")>0?(this.m=3,X(12)):(this.m=0,X(13)),vt(this),Gt(this)}}}catch{}finally{}};function mr(t){if(!Zn(t))return t.g.la();const s=ys(t.g);if(s==="")return"";let r="";const l=s.length,y=ft(t.g)==4;if(!t.h.i){if(typeof TextDecoder>"u")return vt(t),Gt(t),"";t.h.i=new c.TextDecoder}for(let b=0;b<l;b++)t.h.h=!0,r+=t.h.i.decode(s[b],{stream:!(y&&b==l-1)});return s.length=0,t.h.g+=r,t.C=0,t.h.g}function Zn(t){return t.g?t.v=="GET"&&t.M!=2&&t.j.Aa:!1}function yr(t,s){var r=t.C,l=s.indexOf(`
`,r);return l==-1?qe:(r=Number(s.substring(r,l)),isNaN(r)?Yn:(l+=1,l+r>s.length?qe:(s=s.slice(l,l+r),t.C=l+r,s)))}ht.prototype.cancel=function(){this.K=!0,vt(this)};function fe(t){t.T=Date.now()+t.H,Qn(t,t.H)}function Qn(t,s){if(t.D!=null)throw Error("WatchDog timer not null");t.D=zt(T(t.aa,t),s)}function Ge(t){t.D&&(c.clearTimeout(t.D),t.D=null)}ht.prototype.aa=function(){this.D=null;const t=Date.now();t-this.T>=0?(dr(this.i,this.B),this.M!=2&&(Ht(),X(17)),vt(this),this.m=2,Gt(this)):Qn(this,this.T-t)};function Gt(t){t.j.I==0||t.K||Is(t.j,t)}function vt(t){Ge(t);var s=t.O;s&&typeof s.dispose=="function"&&s.dispose(),t.O=null,Fn(t.V),t.g&&(s=t.g,t.g=null,s.abort(),s.dispose())}function We(t,s){try{var r=t.j;if(r.I!=0&&(r.g==t||Xe(r.h,t))){if(!t.L&&Xe(r.h,t)&&r.I==3){try{var l=r.Ba.g.parse(s)}catch{l=null}if(Array.isArray(l)&&l.length==3){var y=l;if(y[0]==0){t:if(!r.v){if(r.g)if(r.g.F+3e3<t.F)_e(r),me(r);else break t;tn(r),X(18)}}else r.xa=y[1],0<r.xa-r.K&&y[2]<37500&&r.F&&r.A==0&&!r.C&&(r.C=zt(T(r.Va,r),6e3));ns(r.h)<=1&&r.ta&&(r.ta=void 0)}else Et(r,11)}else if((t.L||r.g==t)&&_e(r),!f(s))for(y=r.Ba.g.parse(s),s=0;s<y.length;s++){let P=y[s];const H=P[0];if(!(H<=r.K))if(r.K=H,P=P[1],r.I==2)if(P[0]=="c"){r.M=P[1],r.ba=P[2];const st=P[3];st!=null&&(r.ka=st,r.j.info("VER="+r.ka));const It=P[4];It!=null&&(r.za=It,r.j.info("SVER="+r.za));const dt=P[5];dt!=null&&typeof dt=="number"&&dt>0&&(l=1.5*dt,r.O=l,r.j.info("backChannelRequestTimeoutMs_="+l)),l=r;const pt=t.g;if(pt){const we=pt.g?pt.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(we){var b=l.h;b.g||we.indexOf("spdy")==-1&&we.indexOf("quic")==-1&&we.indexOf("h2")==-1||(b.j=b.l,b.g=new Set,b.h&&(Ke(b,b.h),b.h=null))}if(l.G){const nn=pt.g?pt.g.getResponseHeader("X-HTTP-Session-Id"):null;nn&&(l.wa=nn,x(l.J,l.G,nn))}}r.I=3,r.l&&r.l.ra(),r.aa&&(r.T=Date.now()-t.F,r.j.info("Handshake RTT: "+r.T+"ms")),l=r;var E=t;if(l.na=Rs(l,l.L?l.ba:null,l.W),E.L){ss(l.h,E);var R=E,$=l.O;$&&(R.H=$),R.D&&(Ge(R),fe(R)),l.g=E}else Ts(l);r.i.length>0&&ye(r)}else P[0]!="stop"&&P[0]!="close"||Et(r,7);else r.I==3&&(P[0]=="stop"||P[0]=="close"?P[0]=="stop"?Et(r,7):Qe(r):P[0]!="noop"&&r.l&&r.l.qa(P),r.A=0)}}Ht(4)}catch{}}var _r=class{constructor(t,s){this.g=t,this.map=s}};function ts(t){this.l=t||10,c.PerformanceNavigationTiming?(t=c.performance.getEntriesByType("navigation"),t=t.length>0&&(t[0].nextHopProtocol=="hq"||t[0].nextHopProtocol=="h2")):t=!!(c.chrome&&c.chrome.loadTimes&&c.chrome.loadTimes()&&c.chrome.loadTimes().wasFetchedViaSpdy),this.j=t?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function es(t){return t.h?!0:t.g?t.g.size>=t.j:!1}function ns(t){return t.h?1:t.g?t.g.size:0}function Xe(t,s){return t.h?t.h==s:t.g?t.g.has(s):!1}function Ke(t,s){t.g?t.g.add(s):t.h=s}function ss(t,s){t.h&&t.h==s?t.h=null:t.g&&t.g.has(s)&&t.g.delete(s)}ts.prototype.cancel=function(){if(this.i=is(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const t of this.g.values())t.cancel();this.g.clear()}};function is(t){if(t.h!=null)return t.i.concat(t.h.G);if(t.g!=null&&t.g.size!==0){let s=t.i;for(const r of t.g.values())s=s.concat(r.G);return s}return O(t.i)}var rs=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function br(t,s){if(t){t=t.split("&");for(let r=0;r<t.length;r++){const l=t[r].indexOf("=");let y,b=null;l>=0?(y=t[r].substring(0,l),b=t[r].substring(l+1)):y=t[r],s(y,b?decodeURIComponent(b.replace(/\+/g," ")):"")}}}function ct(t){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let s;t instanceof ct?(this.l=t.l,Wt(this,t.j),this.o=t.o,this.g=t.g,Xt(this,t.u),this.h=t.h,Ye(this,us(t.i)),this.m=t.m):t&&(s=String(t).match(rs))?(this.l=!1,Wt(this,s[1]||"",!0),this.o=Kt(s[2]||""),this.g=Kt(s[3]||"",!0),Xt(this,s[4]),this.h=Kt(s[5]||"",!0),Ye(this,s[6]||"",!0),this.m=Kt(s[7]||"")):(this.l=!1,this.i=new Jt(null,this.l))}ct.prototype.toString=function(){const t=[];var s=this.j;s&&t.push(Yt(s,os,!0),":");var r=this.g;return(r||s=="file")&&(t.push("//"),(s=this.o)&&t.push(Yt(s,os,!0),"@"),t.push(Vt(r).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),r=this.u,r!=null&&t.push(":",String(r))),(r=this.h)&&(this.g&&r.charAt(0)!="/"&&t.push("/"),t.push(Yt(r,r.charAt(0)=="/"?Tr:vr,!0))),(r=this.i.toString())&&t.push("?",r),(r=this.m)&&t.push("#",Yt(r,Ir)),t.join("")},ct.prototype.resolve=function(t){const s=nt(this);let r=!!t.j;r?Wt(s,t.j):r=!!t.o,r?s.o=t.o:r=!!t.g,r?s.g=t.g:r=t.u!=null;var l=t.h;if(r)Xt(s,t.u);else if(r=!!t.h){if(l.charAt(0)!="/")if(this.g&&!this.h)l="/"+l;else{var y=s.h.lastIndexOf("/");y!=-1&&(l=s.h.slice(0,y+1)+l)}if(y=l,y==".."||y==".")l="";else if(y.indexOf("./")!=-1||y.indexOf("/.")!=-1){l=y.lastIndexOf("/",0)==0,y=y.split("/");const b=[];for(let E=0;E<y.length;){const R=y[E++];R=="."?l&&E==y.length&&b.push(""):R==".."?((b.length>1||b.length==1&&b[0]!="")&&b.pop(),l&&E==y.length&&b.push("")):(b.push(R),l=!0)}l=b.join("/")}else l=y}return r?s.h=l:r=t.i.toString()!=="",r?Ye(s,us(t.i)):r=!!t.m,r&&(s.m=t.m),s};function nt(t){return new ct(t)}function Wt(t,s,r){t.j=r?Kt(s,!0):s,t.j&&(t.j=t.j.replace(/:$/,""))}function Xt(t,s){if(s){if(s=Number(s),isNaN(s)||s<0)throw Error("Bad port number "+s);t.u=s}else t.u=null}function Ye(t,s,r){s instanceof Jt?(t.i=s,Sr(t.i,t.l)):(r||(s=Yt(s,Er)),t.i=new Jt(s,t.l))}function x(t,s,r){t.i.set(s,r)}function de(t){return x(t,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),t}function Kt(t,s){return t?s?decodeURI(t.replace(/%25/g,"%2525")):decodeURIComponent(t):""}function Yt(t,s,r){return typeof t=="string"?(t=encodeURI(t).replace(s,wr),r&&(t=t.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),t):null}function wr(t){return t=t.charCodeAt(0),"%"+(t>>4&15).toString(16)+(t&15).toString(16)}var os=/[#\/\?@]/g,vr=/[#\?:]/g,Tr=/[#\?]/g,Er=/[#\?@]/g,Ir=/#/g;function Jt(t,s){this.h=this.g=null,this.i=t||null,this.j=!!s}function Tt(t){t.g||(t.g=new Map,t.h=0,t.i&&br(t.i,function(s,r){t.add(decodeURIComponent(s.replace(/\+/g," ")),r)}))}n=Jt.prototype,n.add=function(t,s){Tt(this),this.i=null,t=Ut(this,t);let r=this.g.get(t);return r||this.g.set(t,r=[]),r.push(s),this.h+=1,this};function as(t,s){Tt(t),s=Ut(t,s),t.g.has(s)&&(t.i=null,t.h-=t.g.get(s).length,t.g.delete(s))}function ls(t,s){return Tt(t),s=Ut(t,s),t.g.has(s)}n.forEach=function(t,s){Tt(this),this.g.forEach(function(r,l){r.forEach(function(y){t.call(s,y,l,this)},this)},this)};function hs(t,s){Tt(t);let r=[];if(typeof s=="string")ls(t,s)&&(r=r.concat(t.g.get(Ut(t,s))));else for(t=Array.from(t.g.values()),s=0;s<t.length;s++)r=r.concat(t[s]);return r}n.set=function(t,s){return Tt(this),this.i=null,t=Ut(this,t),ls(this,t)&&(this.h-=this.g.get(t).length),this.g.set(t,[s]),this.h+=1,this},n.get=function(t,s){return t?(t=hs(this,t),t.length>0?String(t[0]):s):s};function cs(t,s,r){as(t,s),r.length>0&&(t.i=null,t.g.set(Ut(t,s),O(r)),t.h+=r.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const t=[],s=Array.from(this.g.keys());for(let l=0;l<s.length;l++){var r=s[l];const y=Vt(r);r=hs(this,r);for(let b=0;b<r.length;b++){let E=y;r[b]!==""&&(E+="="+Vt(r[b])),t.push(E)}}return this.i=t.join("&")};function us(t){const s=new Jt;return s.i=t.i,t.g&&(s.g=new Map(t.g),s.h=t.h),s}function Ut(t,s){return s=String(s),t.j&&(s=s.toLowerCase()),s}function Sr(t,s){s&&!t.j&&(Tt(t),t.i=null,t.g.forEach(function(r,l){const y=l.toLowerCase();l!=y&&(as(this,l),cs(this,y,r))},t)),t.j=s}function Ar(t,s){const r=new qt;if(c.Image){const l=new Image;l.onload=S(ut,r,"TestLoadImage: loaded",!0,s,l),l.onerror=S(ut,r,"TestLoadImage: error",!1,s,l),l.onabort=S(ut,r,"TestLoadImage: abort",!1,s,l),l.ontimeout=S(ut,r,"TestLoadImage: timeout",!1,s,l),c.setTimeout(function(){l.ontimeout&&l.ontimeout()},1e4),l.src=t}else s(!1)}function Rr(t,s){const r=new qt,l=new AbortController,y=setTimeout(()=>{l.abort(),ut(r,"TestPingServer: timeout",!1,s)},1e4);fetch(t,{signal:l.signal}).then(b=>{clearTimeout(y),b.ok?ut(r,"TestPingServer: ok",!0,s):ut(r,"TestPingServer: server error",!1,s)}).catch(()=>{clearTimeout(y),ut(r,"TestPingServer: error",!1,s)})}function ut(t,s,r,l,y){try{y&&(y.onload=null,y.onerror=null,y.onabort=null,y.ontimeout=null),l(r)}catch{}}function Cr(){this.g=new cr}function Je(t){this.i=t.Sb||null,this.h=t.ab||!1}I(Je,$n),Je.prototype.g=function(){return new pe(this.i,this.h)};function pe(t,s){V.call(this),this.H=t,this.o=s,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}I(pe,V),n=pe.prototype,n.open=function(t,s){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=t,this.D=s,this.readyState=1,Qt(this)},n.send=function(t){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const s={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};t&&(s.body=t),(this.H||c).fetch(new Request(this.D,s)).then(this.Pa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Zt(this)),this.readyState=0},n.Pa=function(t){if(this.g&&(this.l=t,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=t.headers,this.readyState=2,Qt(this)),this.g&&(this.readyState=3,Qt(this),this.g)))if(this.responseType==="arraybuffer")t.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof c.ReadableStream<"u"&&"body"in t){if(this.j=t.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;fs(this)}else t.text().then(this.Oa.bind(this),this.ga.bind(this))};function fs(t){t.j.read().then(t.Ma.bind(t)).catch(t.ga.bind(t))}n.Ma=function(t){if(this.g){if(this.o&&t.value)this.response.push(t.value);else if(!this.o){var s=t.value?t.value:new Uint8Array(0);(s=this.B.decode(s,{stream:!t.done}))&&(this.response=this.responseText+=s)}t.done?Zt(this):Qt(this),this.readyState==3&&fs(this)}},n.Oa=function(t){this.g&&(this.response=this.responseText=t,Zt(this))},n.Na=function(t){this.g&&(this.response=t,Zt(this))},n.ga=function(){this.g&&Zt(this)};function Zt(t){t.readyState=4,t.l=null,t.j=null,t.B=null,Qt(t)}n.setRequestHeader=function(t,s){this.A.append(t,s)},n.getResponseHeader=function(t){return this.h&&this.h.get(t.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const t=[],s=this.h.entries();for(var r=s.next();!r.done;)r=r.value,t.push(r[0]+": "+r[1]),r=s.next();return t.join(`\r
`)};function Qt(t){t.onreadystatechange&&t.onreadystatechange.call(t)}Object.defineProperty(pe.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(t){this.m=t?"include":"same-origin"}});function ds(t){let s="";return ae(t,function(r,l){s+=l,s+=":",s+=r,s+=`\r
`}),s}function Ze(t,s,r){t:{for(l in r){var l=!1;break t}l=!0}l||(r=ds(r),typeof t=="string"?r!=null&&Vt(r):x(t,s,r))}function j(t){V.call(this),this.headers=new Map,this.L=t||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}I(j,V);var kr=/^https?$/i,Or=["POST","PUT"];n=j.prototype,n.Fa=function(t){this.H=t},n.ea=function(t,s,r,l){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+t);s=s?s.toUpperCase():"GET",this.D=t,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():Xn.g(),this.g.onreadystatechange=C(T(this.Ca,this));try{this.B=!0,this.g.open(s,String(t),!0),this.B=!1}catch(b){ps(this,b);return}if(t=r||"",r=new Map(this.headers),l)if(Object.getPrototypeOf(l)===Object.prototype)for(var y in l)r.set(y,l[y]);else if(typeof l.keys=="function"&&typeof l.get=="function")for(const b of l.keys())r.set(b,l.get(b));else throw Error("Unknown input type for opt_headers: "+String(l));l=Array.from(r.keys()).find(b=>b.toLowerCase()=="content-type"),y=c.FormData&&t instanceof c.FormData,!(Array.prototype.indexOf.call(Or,s,void 0)>=0)||l||y||r.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[b,E]of r)this.g.setRequestHeader(b,E);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(t),this.v=!1}catch(b){ps(this,b)}};function ps(t,s){t.h=!1,t.g&&(t.j=!0,t.g.abort(),t.j=!1),t.l=s,t.o=5,gs(t),ge(t)}function gs(t){t.A||(t.A=!0,W(t,"complete"),W(t,"error"))}n.abort=function(t){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=t||7,W(this,"complete"),W(this,"abort"),ge(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),ge(this,!0)),j.Z.N.call(this)},n.Ca=function(){this.u||(this.B||this.v||this.j?ms(this):this.Xa())},n.Xa=function(){ms(this)};function ms(t){if(t.h&&typeof h<"u"){if(t.v&&ft(t)==4)setTimeout(t.Ca.bind(t),0);else if(W(t,"readystatechange"),ft(t)==4){t.h=!1;try{const b=t.ca();t:switch(b){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var s=!0;break t;default:s=!1}var r;if(!(r=s)){var l;if(l=b===0){let E=String(t.D).match(rs)[1]||null;!E&&c.self&&c.self.location&&(E=c.self.location.protocol.slice(0,-1)),l=!kr.test(E?E.toLowerCase():"")}r=l}if(r)W(t,"complete"),W(t,"success");else{t.o=6;try{var y=ft(t)>2?t.g.statusText:""}catch{y=""}t.l=y+" ["+t.ca()+"]",gs(t)}}finally{ge(t)}}}}function ge(t,s){if(t.g){t.m&&(clearTimeout(t.m),t.m=null);const r=t.g;t.g=null,s||W(t,"ready");try{r.onreadystatechange=null}catch{}}}n.isActive=function(){return!!this.g};function ft(t){return t.g?t.g.readyState:0}n.ca=function(){try{return ft(this)>2?this.g.status:-1}catch{return-1}},n.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.La=function(t){if(this.g){var s=this.g.responseText;return t&&s.indexOf(t)==0&&(s=s.substring(t.length)),hr(s)}};function ys(t){try{if(!t.g)return null;if("response"in t.g)return t.g.response;switch(t.F){case"":case"text":return t.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in t.g)return t.g.mozResponseArrayBuffer}return null}catch{return null}}function Dr(t){const s={};t=(t.g&&ft(t)>=2&&t.g.getAllResponseHeaders()||"").split(`\r
`);for(let l=0;l<t.length;l++){if(f(t[l]))continue;var r=gr(t[l]);const y=r[0];if(r=r[1],typeof r!="string")continue;r=r.trim();const b=s[y]||[];s[y]=b,b.push(r)}sr(s,function(l){return l.join(", ")})}n.ya=function(){return this.o},n.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function te(t,s,r){return r&&r.internalChannelParams&&r.internalChannelParams[t]||s}function _s(t){this.za=0,this.i=[],this.j=new qt,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=te("failFast",!1,t),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=te("baseRetryDelayMs",5e3,t),this.Za=te("retryDelaySeedMs",1e4,t),this.Ta=te("forwardChannelMaxRetries",2,t),this.va=te("forwardChannelRequestTimeoutMs",2e4,t),this.ma=t&&t.xmlHttpFactory||void 0,this.Ua=t&&t.Rb||void 0,this.Aa=t&&t.useFetchStreams||!1,this.O=void 0,this.L=t&&t.supportsCrossDomainXhr||!1,this.M="",this.h=new ts(t&&t.concurrentRequestLimit),this.Ba=new Cr,this.S=t&&t.fastHandshake||!1,this.R=t&&t.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=t&&t.Pb||!1,t&&t.ua&&this.j.ua(),t&&t.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&t&&t.detectBufferingProxy||!1,this.ia=void 0,t&&t.longPollingTimeout&&t.longPollingTimeout>0&&(this.ia=t.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}n=_s.prototype,n.ka=8,n.I=1,n.connect=function(t,s,r,l){X(0),this.W=t,this.H=s||{},r&&l!==void 0&&(this.H.OSID=r,this.H.OAID=l),this.F=this.X,this.J=Rs(this,null,this.W),ye(this)};function Qe(t){if(bs(t),t.I==3){var s=t.V++,r=nt(t.J);if(x(r,"SID",t.M),x(r,"RID",s),x(r,"TYPE","terminate"),ee(t,r),s=new ht(t,t.j,s),s.M=2,s.A=de(nt(r)),r=!1,c.navigator&&c.navigator.sendBeacon)try{r=c.navigator.sendBeacon(s.A.toString(),"")}catch{}!r&&c.Image&&(new Image().src=s.A,r=!0),r||(s.g=Cs(s.j,null),s.g.ea(s.A)),s.F=Date.now(),fe(s)}As(t)}function me(t){t.g&&(en(t),t.g.cancel(),t.g=null)}function bs(t){me(t),t.v&&(c.clearTimeout(t.v),t.v=null),_e(t),t.h.cancel(),t.m&&(typeof t.m=="number"&&c.clearTimeout(t.m),t.m=null)}function ye(t){if(!es(t.h)&&!t.m){t.m=!0;var s=t.Ea;G||u(),F||(G(),F=!0),g.add(s,t),t.D=0}}function Pr(t,s){return ns(t.h)>=t.h.j-(t.m?1:0)?!1:t.m?(t.i=s.G.concat(t.i),!0):t.I==1||t.I==2||t.D>=(t.Sa?0:t.Ta)?!1:(t.m=zt(T(t.Ea,t,s),Ss(t,t.D)),t.D++,!0)}n.Ea=function(t){if(this.m)if(this.m=null,this.I==1){if(!t){this.V=Math.floor(Math.random()*1e5),t=this.V++;const y=new ht(this,this.j,t);let b=this.o;if(this.U&&(b?(b=Dn(b),Nn(b,this.U)):b=this.U),this.u!==null||this.R||(y.J=b,b=null),this.S)t:{for(var s=0,r=0;r<this.i.length;r++){e:{var l=this.i[r];if("__data__"in l.map&&(l=l.map.__data__,typeof l=="string")){l=l.length;break e}l=void 0}if(l===void 0)break;if(s+=l,s>4096){s=r;break t}if(s===4096||r===this.i.length-1){s=r+1;break t}}s=1e3}else s=1e3;s=vs(this,y,s),r=nt(this.J),x(r,"RID",t),x(r,"CVER",22),this.G&&x(r,"X-HTTP-Session-Id",this.G),ee(this,r),b&&(this.R?s="headers="+Vt(ds(b))+"&"+s:this.u&&Ze(r,this.u,b)),Ke(this.h,y),this.Ra&&x(r,"TYPE","init"),this.S?(x(r,"$req",s),x(r,"SID","null"),y.U=!0,Ve(y,r,null)):Ve(y,r,s),this.I=2}}else this.I==3&&(t?ws(this,t):this.i.length==0||es(this.h)||ws(this))};function ws(t,s){var r;s?r=s.l:r=t.V++;const l=nt(t.J);x(l,"SID",t.M),x(l,"RID",r),x(l,"AID",t.K),ee(t,l),t.u&&t.o&&Ze(l,t.u,t.o),r=new ht(t,t.j,r,t.D+1),t.u===null&&(r.J=t.o),s&&(t.i=s.G.concat(t.i)),s=vs(t,r,1e3),r.H=Math.round(t.va*.5)+Math.round(t.va*.5*Math.random()),Ke(t.h,r),Ve(r,l,s)}function ee(t,s){t.H&&ae(t.H,function(r,l){x(s,l,r)}),t.l&&ae({},function(r,l){x(s,l,r)})}function vs(t,s,r){r=Math.min(t.i.length,r);const l=t.l?T(t.l.Ka,t.l,t):null;t:{var y=t.i;let R=-1;for(;;){const $=["count="+r];R==-1?r>0?(R=y[0].g,$.push("ofs="+R)):R=0:$.push("ofs="+R);let P=!0;for(let H=0;H<r;H++){var b=y[H].g;const st=y[H].map;if(b-=R,b<0)R=Math.max(0,y[H].g-100),P=!1;else try{b="req"+b+"_"||"";try{var E=st instanceof Map?st:Object.entries(st);for(const[It,dt]of E){let pt=dt;w(dt)&&(pt=Fe(dt)),$.push(b+It+"="+encodeURIComponent(pt))}}catch(It){throw $.push(b+"type="+encodeURIComponent("_badmap")),It}}catch{l&&l(st)}}if(P){E=$.join("&");break t}}E=void 0}return t=t.i.splice(0,r),s.G=t,E}function Ts(t){if(!t.g&&!t.v){t.Y=1;var s=t.Da;G||u(),F||(G(),F=!0),g.add(s,t),t.A=0}}function tn(t){return t.g||t.v||t.A>=3?!1:(t.Y++,t.v=zt(T(t.Da,t),Ss(t,t.A)),t.A++,!0)}n.Da=function(){if(this.v=null,Es(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var t=4*this.T;this.j.info("BP detection timer enabled: "+t),this.B=zt(T(this.Wa,this),t)}},n.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,X(10),me(this),Es(this))};function en(t){t.B!=null&&(c.clearTimeout(t.B),t.B=null)}function Es(t){t.g=new ht(t,t.j,"rpc",t.Y),t.u===null&&(t.g.J=t.o),t.g.P=0;var s=nt(t.na);x(s,"RID","rpc"),x(s,"SID",t.M),x(s,"AID",t.K),x(s,"CI",t.F?"0":"1"),!t.F&&t.ia&&x(s,"TO",t.ia),x(s,"TYPE","xmlhttp"),ee(t,s),t.u&&t.o&&Ze(s,t.u,t.o),t.O&&(t.g.H=t.O);var r=t.g;t=t.ba,r.M=1,r.A=de(nt(s)),r.u=null,r.R=!0,Jn(r,t)}n.Va=function(){this.C!=null&&(this.C=null,me(this),tn(this),X(19))};function _e(t){t.C!=null&&(c.clearTimeout(t.C),t.C=null)}function Is(t,s){var r=null;if(t.g==s){_e(t),en(t),t.g=null;var l=2}else if(Xe(t.h,s))r=s.G,ss(t.h,s),l=1;else return;if(t.I!=0){if(s.o)if(l==1){r=s.u?s.u.length:0,s=Date.now()-s.F;var y=t.D;l=ce(),W(l,new Gn(l,r)),ye(t)}else Ts(t);else if(y=s.m,y==3||y==0&&s.X>0||!(l==1&&Pr(t,s)||l==2&&tn(t)))switch(r&&r.length>0&&(s=t.h,s.i=s.i.concat(r)),y){case 1:Et(t,5);break;case 4:Et(t,10);break;case 3:Et(t,6);break;default:Et(t,2)}}}function Ss(t,s){let r=t.Qa+Math.floor(Math.random()*t.Za);return t.isActive()||(r*=2),r*s}function Et(t,s){if(t.j.info("Error code "+s),s==2){var r=T(t.bb,t),l=t.Ua;const y=!l;l=new ct(l||"//www.google.com/images/cleardot.gif"),c.location&&c.location.protocol=="http"||Wt(l,"https"),de(l),y?Ar(l.toString(),r):Rr(l.toString(),r)}else X(2);t.I=0,t.l&&t.l.pa(s),As(t),bs(t)}n.bb=function(t){t?(this.j.info("Successfully pinged google.com"),X(2)):(this.j.info("Failed to ping google.com"),X(1))};function As(t){if(t.I=0,t.ja=[],t.l){const s=is(t.h);(s.length!=0||t.i.length!=0)&&(k(t.ja,s),k(t.ja,t.i),t.h.i.length=0,O(t.i),t.i.length=0),t.l.oa()}}function Rs(t,s,r){var l=r instanceof ct?nt(r):new ct(r);if(l.g!="")s&&(l.g=s+"."+l.g),Xt(l,l.u);else{var y=c.location;l=y.protocol,s=s?s+"."+y.hostname:y.hostname,y=+y.port;const b=new ct(null);l&&Wt(b,l),s&&(b.g=s),y&&Xt(b,y),r&&(b.h=r),l=b}return r=t.G,s=t.wa,r&&s&&x(l,r,s),x(l,"VER",t.ka),ee(t,l),l}function Cs(t,s,r){if(s&&!t.L)throw Error("Can't create secondary domain capable XhrIo object.");return s=t.Aa&&!t.ma?new j(new Je({ab:r})):new j(t.ma),s.Fa(t.L),s}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function ks(){}n=ks.prototype,n.ra=function(){},n.qa=function(){},n.pa=function(){},n.oa=function(){},n.isActive=function(){return!0},n.Ka=function(){};function be(){}be.prototype.g=function(t,s){return new Q(t,s)};function Q(t,s){V.call(this),this.g=new _s(s),this.l=t,this.h=s&&s.messageUrlParams||null,t=s&&s.messageHeaders||null,s&&s.clientProtocolHeaderRequired&&(t?t["X-Client-Protocol"]="webchannel":t={"X-Client-Protocol":"webchannel"}),this.g.o=t,t=s&&s.initMessageHeaders||null,s&&s.messageContentType&&(t?t["X-WebChannel-Content-Type"]=s.messageContentType:t={"X-WebChannel-Content-Type":s.messageContentType}),s&&s.sa&&(t?t["X-WebChannel-Client-Profile"]=s.sa:t={"X-WebChannel-Client-Profile":s.sa}),this.g.U=t,(t=s&&s.Qb)&&!f(t)&&(this.g.u=t),this.A=s&&s.supportsCrossDomainXhr||!1,this.v=s&&s.sendRawJson||!1,(s=s&&s.httpSessionIdParam)&&!f(s)&&(this.g.G=s,t=this.h,t!==null&&s in t&&(t=this.h,s in t&&delete t[s])),this.j=new Mt(this)}I(Q,V),Q.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},Q.prototype.close=function(){Qe(this.g)},Q.prototype.o=function(t){var s=this.g;if(typeof t=="string"){var r={};r.__data__=t,t=r}else this.v&&(r={},r.__data__=Fe(t),t=r);s.i.push(new _r(s.Ya++,t)),s.I==3&&ye(s)},Q.prototype.N=function(){this.g.l=null,delete this.j,Qe(this.g),delete this.g,Q.Z.N.call(this)};function Os(t){$e.call(this),t.__headers__&&(this.headers=t.__headers__,this.statusCode=t.__status__,delete t.__headers__,delete t.__status__);var s=t.__sm__;if(s){t:{for(const r in s){t=r;break t}t=void 0}(this.i=t)&&(t=this.i,s=s!==null&&t in s?s[t]:void 0),this.data=s}else this.data=t}I(Os,$e);function Ds(){He.call(this),this.status=1}I(Ds,He);function Mt(t){this.g=t}I(Mt,ks),Mt.prototype.ra=function(){W(this.g,"a")},Mt.prototype.qa=function(t){W(this.g,new Os(t))},Mt.prototype.pa=function(t){W(this.g,new Ds)},Mt.prototype.oa=function(){W(this.g,"b")},be.prototype.createWebChannel=be.prototype.g,Q.prototype.send=Q.prototype.o,Q.prototype.open=Q.prototype.m,Q.prototype.close=Q.prototype.close,ma=function(){return new be},ga=function(){return ce()},pa=wt,da={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},ue.NO_ERROR=0,ue.TIMEOUT=8,ue.HTTP_ERROR=6,fa=ue,Wn.COMPLETE="complete",ua=Wn,Hn.EventType=$t,$t.OPEN="a",$t.CLOSE="b",$t.ERROR="c",$t.MESSAGE="d",V.prototype.listen=V.prototype.J,ca=Hn,j.prototype.listenOnce=j.prototype.K,j.prototype.getLastError=j.prototype.Ha,j.prototype.getLastErrorCode=j.prototype.ya,j.prototype.getStatus=j.prototype.ca,j.prototype.getResponseJson=j.prototype.La,j.prototype.getResponseText=j.prototype.la,j.prototype.send=j.prototype.ea,j.prototype.setWithCredentials=j.prototype.Fa,ha=j}).apply(typeof ve<"u"?ve:typeof self<"u"?self:typeof window<"u"?window:{});var ya="firebase",_a="12.12.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */rt(ya,_a,"app");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const di="firebasestorage.googleapis.com",pi="storageBucket",ba=120*1e3,wa=600*1e3,va=1e3;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class B extends _t{constructor(e,i,o=0){super(on(e),`Firebase Storage: ${i} (${on(e)})`),this.status_=o,this.customData={serverResponse:null},this._baseMessage=this.message,Object.setPrototypeOf(this,B.prototype)}get status(){return this.status_}set status(e){this.status_=e}_codeEquals(e){return on(e)===this.code}get serverResponse(){return this.customData.serverResponse}set serverResponse(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=`${this._baseMessage}
${this.customData.serverResponse}`:this.message=this._baseMessage}}var M;(function(n){n.UNKNOWN="unknown",n.OBJECT_NOT_FOUND="object-not-found",n.BUCKET_NOT_FOUND="bucket-not-found",n.PROJECT_NOT_FOUND="project-not-found",n.QUOTA_EXCEEDED="quota-exceeded",n.UNAUTHENTICATED="unauthenticated",n.UNAUTHORIZED="unauthorized",n.UNAUTHORIZED_APP="unauthorized-app",n.RETRY_LIMIT_EXCEEDED="retry-limit-exceeded",n.INVALID_CHECKSUM="invalid-checksum",n.CANCELED="canceled",n.INVALID_EVENT_NAME="invalid-event-name",n.INVALID_URL="invalid-url",n.INVALID_DEFAULT_BUCKET="invalid-default-bucket",n.NO_DEFAULT_BUCKET="no-default-bucket",n.CANNOT_SLICE_BLOB="cannot-slice-blob",n.SERVER_FILE_WRONG_SIZE="server-file-wrong-size",n.NO_DOWNLOAD_URL="no-download-url",n.INVALID_ARGUMENT="invalid-argument",n.INVALID_ARGUMENT_COUNT="invalid-argument-count",n.APP_DELETED="app-deleted",n.INVALID_ROOT_OPERATION="invalid-root-operation",n.INVALID_FORMAT="invalid-format",n.INTERNAL_ERROR="internal-error",n.UNSUPPORTED_ENVIRONMENT="unsupported-environment"})(M||(M={}));function on(n){return"storage/"+n}function bn(){const n="An unknown error occurred, please check the error payload for server response.";return new B(M.UNKNOWN,n)}function Ta(n){return new B(M.OBJECT_NOT_FOUND,"Object '"+n+"' does not exist.")}function Ea(n){return new B(M.QUOTA_EXCEEDED,"Quota for bucket '"+n+"' exceeded, please view quota on https://firebase.google.com/pricing/.")}function Ia(){const n="User is not authenticated, please authenticate using Firebase Authentication and try again.";return new B(M.UNAUTHENTICATED,n)}function Sa(){return new B(M.UNAUTHORIZED_APP,"This app does not have permission to access Firebase Storage on this project.")}function Aa(n){return new B(M.UNAUTHORIZED,"User does not have permission to access '"+n+"'.")}function gi(){return new B(M.RETRY_LIMIT_EXCEEDED,"Max retry time for operation exceeded, please try again.")}function mi(){return new B(M.CANCELED,"User canceled the upload/download.")}function Ra(n){return new B(M.INVALID_URL,"Invalid URL '"+n+"'.")}function Ca(n){return new B(M.INVALID_DEFAULT_BUCKET,"Invalid default bucket '"+n+"'.")}function ka(){return new B(M.NO_DEFAULT_BUCKET,"No default bucket found. Did you set the '"+pi+"' property when initializing the app?")}function yi(){return new B(M.CANNOT_SLICE_BLOB,"Cannot slice blob for upload. Please retry the upload.")}function Oa(){return new B(M.SERVER_FILE_WRONG_SIZE,"Server recorded incorrect upload file size, please retry the upload.")}function Da(){return new B(M.NO_DOWNLOAD_URL,"The given file does not have any download URLs.")}function Pa(n){return new B(M.UNSUPPORTED_ENVIRONMENT,`${n} is missing. Make sure to install the required polyfills. See https://firebase.google.com/docs/web/environments-js-sdk#polyfills for more information.`)}function mn(n){return new B(M.INVALID_ARGUMENT,n)}function _i(){return new B(M.APP_DELETED,"The Firebase app was deleted.")}function Na(n){return new B(M.INVALID_ROOT_OPERATION,"The operation '"+n+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}function se(n,e){return new B(M.INVALID_FORMAT,"String does not match format '"+n+"': "+e)}function ne(n){throw new B(M.INTERNAL_ERROR,"Internal error: "+n)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tt{constructor(e,i){this.bucket=e,this.path_=i}get path(){return this.path_}get isRoot(){return this.path.length===0}fullServerUrl(){const e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)}bucketOnlyServerUrl(){return"/b/"+encodeURIComponent(this.bucket)+"/o"}static makeFromBucketSpec(e,i){let o;try{o=tt.makeFromUrl(e,i)}catch{return new tt(e,"")}if(o.path==="")return o;throw Ca(e)}static makeFromUrl(e,i){let o=null;const a="([A-Za-z0-9.\\-_]+)";function h(L){L.path.charAt(L.path.length-1)==="/"&&(L.path_=L.path_.slice(0,-1))}const c="(/(.*))?$",w=new RegExp("^gs://"+a+c,"i"),v={bucket:1,path:3};function T(L){L.path_=decodeURIComponent(L.path)}const S="v[A-Za-z0-9_]+",I=i.replace(/[.]/g,"\\."),C="(/([^?#]*).*)?$",O=new RegExp(`^https?://${I}/${S}/b/${a}/o${C}`,"i"),k={bucket:1,path:3},D=i===di?"(?:storage.googleapis.com|storage.cloud.google.com)":i,A="([^?#]*)",z=new RegExp(`^https?://${D}/${a}/${A}`,"i"),N=[{regex:w,indices:v,postModify:h},{regex:O,indices:k,postModify:T},{regex:z,indices:{bucket:1,path:2},postModify:T}];for(let L=0;L<N.length;L++){const G=N[L],F=G.regex.exec(e);if(F){const g=F[G.indices.bucket];let u=F[G.indices.path];u||(u=""),o=new tt(g,u),G.postModify(o);break}}if(o==null)throw Ra(e);return o}}class xa{constructor(e){this.promise_=Promise.reject(e)}getPromise(){return this.promise_}cancel(e=!1){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ua(n,e,i){let o=1,a=null,h=null,c=!1,w=0;function v(){return w===2}let T=!1;function S(...A){T||(T=!0,e.apply(null,A))}function I(A){a=setTimeout(()=>{a=null,n(O,v())},A)}function C(){h&&clearTimeout(h)}function O(A,...z){if(T){C();return}if(A){C(),S.call(null,A,...z);return}if(v()||c){C(),S.call(null,A,...z);return}o<64&&(o*=2);let N;w===1?(w=2,N=0):N=(o+Math.random())*1e3,I(N)}let k=!1;function D(A){k||(k=!0,C(),!T&&(a!==null?(A||(w=2),clearTimeout(a),I(0)):A||(w=1)))}return I(0),h=setTimeout(()=>{c=!0,D(!0)},i),D}function Ma(n){n(!1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function La(n){return n!==void 0}function Ba(n){return typeof n=="function"}function ja(n){return typeof n=="object"&&!Array.isArray(n)}function Oe(n){return typeof n=="string"||n instanceof String}function $s(n){return wn()&&n instanceof Blob}function wn(){return typeof Blob<"u"}function Hs(n,e,i,o){if(o<e)throw mn(`Invalid value for '${n}'. Expected ${e} or greater.`);if(o>i)throw mn(`Invalid value for '${n}'. Expected ${i} or less.`)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jt(n,e,i){let o=e;return i==null&&(o=`https://${e}`),`${i}://${o}/v0${n}`}function bi(n){const e=encodeURIComponent;let i="?";for(const o in n)if(n.hasOwnProperty(o)){const a=e(o)+"="+e(n[o]);i=i+a+"&"}return i=i.slice(0,-1),i}var Ct;(function(n){n[n.NO_ERROR=0]="NO_ERROR",n[n.NETWORK_ERROR=1]="NETWORK_ERROR",n[n.ABORT=2]="ABORT"})(Ct||(Ct={}));/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wi(n,e){const i=n>=500&&n<600,a=[408,429].indexOf(n)!==-1,h=e.indexOf(n)!==-1;return i||a||h}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fa{constructor(e,i,o,a,h,c,w,v,T,S,I,C=!0,O=!1){this.url_=e,this.method_=i,this.headers_=o,this.body_=a,this.successCodes_=h,this.additionalRetryCodes_=c,this.callback_=w,this.errorCallback_=v,this.timeout_=T,this.progressCallback_=S,this.connectionFactory_=I,this.retry=C,this.isUsingEmulator=O,this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.promise_=new Promise((k,D)=>{this.resolve_=k,this.reject_=D,this.start_()})}start_(){const e=(o,a)=>{if(a){o(!1,new Te(!1,null,!0));return}const h=this.connectionFactory_();this.pendingConnection_=h;const c=w=>{const v=w.loaded,T=w.lengthComputable?w.total:-1;this.progressCallback_!==null&&this.progressCallback_(v,T)};this.progressCallback_!==null&&h.addUploadProgressListener(c),h.send(this.url_,this.method_,this.isUsingEmulator,this.body_,this.headers_).then(()=>{this.progressCallback_!==null&&h.removeUploadProgressListener(c),this.pendingConnection_=null;const w=h.getErrorCode()===Ct.NO_ERROR,v=h.getStatus();if(!w||wi(v,this.additionalRetryCodes_)&&this.retry){const S=h.getErrorCode()===Ct.ABORT;o(!1,new Te(!1,null,S));return}const T=this.successCodes_.indexOf(v)!==-1;o(!0,new Te(T,h))})},i=(o,a)=>{const h=this.resolve_,c=this.reject_,w=a.connection;if(a.wasSuccessCode)try{const v=this.callback_(w,w.getResponse());La(v)?h(v):h()}catch(v){c(v)}else if(w!==null){const v=bn();v.serverResponse=w.getErrorText(),this.errorCallback_?c(this.errorCallback_(w,v)):c(v)}else if(a.canceled){const v=this.appDelete_?_i():mi();c(v)}else{const v=gi();c(v)}};this.canceled_?i(!1,new Te(!1,null,!0)):this.backoffId_=Ua(e,i,this.timeout_)}getPromise(){return this.promise_}cancel(e){this.canceled_=!0,this.appDelete_=e||!1,this.backoffId_!==null&&Ma(this.backoffId_),this.pendingConnection_!==null&&this.pendingConnection_.abort()}}class Te{constructor(e,i,o){this.wasSuccessCode=e,this.connection=i,this.canceled=!!o}}function $a(n,e){e!==null&&e.length>0&&(n.Authorization="Firebase "+e)}function Ha(n,e){n["X-Firebase-Storage-Version"]="webjs/"+(e??"AppManager")}function za(n,e){e&&(n["X-Firebase-GMPID"]=e)}function qa(n,e){e!==null&&(n["X-Firebase-AppCheck"]=e)}function Va(n,e,i,o,a,h,c=!0,w=!1){const v=bi(n.urlParams),T=n.url+v,S=Object.assign({},n.headers);return za(S,e),$a(S,i),Ha(S,h),qa(S,o),new Fa(T,n.method,S,n.body,n.successCodes,n.additionalRetryCodes,n.handler,n.errorHandler,n.timeout,n.progressCallback,a,c,w)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ga(){return typeof BlobBuilder<"u"?BlobBuilder:typeof WebKitBlobBuilder<"u"?WebKitBlobBuilder:void 0}function Wa(...n){const e=Ga();if(e!==void 0){const i=new e;for(let o=0;o<n.length;o++)i.append(n[o]);return i.getBlob()}else{if(wn())return new Blob(n);throw new B(M.UNSUPPORTED_ENVIRONMENT,"This browser doesn't seem to support creating Blobs")}}function Xa(n,e,i){return n.webkitSlice?n.webkitSlice(e,i):n.mozSlice?n.mozSlice(e,i):n.slice?n.slice(e,i):null}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ka(n){if(typeof atob>"u")throw Pa("base-64");return atob(n)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const it={RAW:"raw",BASE64:"base64",BASE64URL:"base64url",DATA_URL:"data_url"};class an{constructor(e,i){this.data=e,this.contentType=i||null}}function Ya(n,e){switch(n){case it.RAW:return new an(vi(e));case it.BASE64:case it.BASE64URL:return new an(Ti(n,e));case it.DATA_URL:return new an(Za(e),Qa(e))}throw bn()}function vi(n){const e=[];for(let i=0;i<n.length;i++){let o=n.charCodeAt(i);if(o<=127)e.push(o);else if(o<=2047)e.push(192|o>>6,128|o&63);else if((o&64512)===55296)if(!(i<n.length-1&&(n.charCodeAt(i+1)&64512)===56320))e.push(239,191,189);else{const h=o,c=n.charCodeAt(++i);o=65536|(h&1023)<<10|c&1023,e.push(240|o>>18,128|o>>12&63,128|o>>6&63,128|o&63)}else(o&64512)===56320?e.push(239,191,189):e.push(224|o>>12,128|o>>6&63,128|o&63)}return new Uint8Array(e)}function Ja(n){let e;try{e=decodeURIComponent(n)}catch{throw se(it.DATA_URL,"Malformed data URL.")}return vi(e)}function Ti(n,e){switch(n){case it.BASE64:{const a=e.indexOf("-")!==-1,h=e.indexOf("_")!==-1;if(a||h)throw se(n,"Invalid character '"+(a?"-":"_")+"' found: is it base64url encoded?");break}case it.BASE64URL:{const a=e.indexOf("+")!==-1,h=e.indexOf("/")!==-1;if(a||h)throw se(n,"Invalid character '"+(a?"+":"/")+"' found: is it base64 encoded?");e=e.replace(/-/g,"+").replace(/_/g,"/");break}}let i;try{i=Ka(e)}catch(a){throw a.message.includes("polyfill")?a:se(n,"Invalid character found")}const o=new Uint8Array(i.length);for(let a=0;a<i.length;a++)o[a]=i.charCodeAt(a);return o}class Ei{constructor(e){this.base64=!1,this.contentType=null;const i=e.match(/^data:([^,]+)?,/);if(i===null)throw se(it.DATA_URL,"Must be formatted 'data:[<mediatype>][;base64],<data>");const o=i[1]||null;o!=null&&(this.base64=tl(o,";base64"),this.contentType=this.base64?o.substring(0,o.length-7):o),this.rest=e.substring(e.indexOf(",")+1)}}function Za(n){const e=new Ei(n);return e.base64?Ti(it.BASE64,e.rest):Ja(e.rest)}function Qa(n){return new Ei(n).contentType}function tl(n,e){return n.length>=e.length?n.substring(n.length-e.length)===e:!1}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gt{constructor(e,i){let o=0,a="";$s(e)?(this.data_=e,o=e.size,a=e.type):e instanceof ArrayBuffer?(i?this.data_=new Uint8Array(e):(this.data_=new Uint8Array(e.byteLength),this.data_.set(new Uint8Array(e))),o=this.data_.length):e instanceof Uint8Array&&(i?this.data_=e:(this.data_=new Uint8Array(e.length),this.data_.set(e)),o=e.length),this.size_=o,this.type_=a}size(){return this.size_}type(){return this.type_}slice(e,i){if($s(this.data_)){const o=this.data_,a=Xa(o,e,i);return a===null?null:new gt(a)}else{const o=new Uint8Array(this.data_.buffer,e,i-e);return new gt(o,!0)}}static getBlob(...e){if(wn()){const i=e.map(o=>o instanceof gt?o.data_:o);return new gt(Wa.apply(null,i))}else{const i=e.map(c=>Oe(c)?Ya(it.RAW,c).data:c.data_);let o=0;i.forEach(c=>{o+=c.byteLength});const a=new Uint8Array(o);let h=0;return i.forEach(c=>{for(let w=0;w<c.length;w++)a[h++]=c[w]}),new gt(a,!0)}}uploadData(){return this.data_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ii(n){let e;try{e=JSON.parse(n)}catch{return null}return ja(e)?e:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function el(n){if(n.length===0)return null;const e=n.lastIndexOf("/");return e===-1?"":n.slice(0,e)}function nl(n,e){const i=e.split("/").filter(o=>o.length>0).join("/");return n.length===0?i:n+"/"+i}function Si(n){const e=n.lastIndexOf("/",n.length-2);return e===-1?n:n.slice(e+1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sl(n,e){return e}class K{constructor(e,i,o,a){this.server=e,this.local=i||e,this.writable=!!o,this.xform=a||sl}}let Ee=null;function il(n){return!Oe(n)||n.length<2?n:Si(n)}function Ai(){if(Ee)return Ee;const n=[];n.push(new K("bucket")),n.push(new K("generation")),n.push(new K("metageneration")),n.push(new K("name","fullPath",!0));function e(h,c){return il(c)}const i=new K("name");i.xform=e,n.push(i);function o(h,c){return c!==void 0?Number(c):c}const a=new K("size");return a.xform=o,n.push(a),n.push(new K("timeCreated")),n.push(new K("updated")),n.push(new K("md5Hash",null,!0)),n.push(new K("cacheControl",null,!0)),n.push(new K("contentDisposition",null,!0)),n.push(new K("contentEncoding",null,!0)),n.push(new K("contentLanguage",null,!0)),n.push(new K("contentType",null,!0)),n.push(new K("metadata","customMetadata",!0)),Ee=n,Ee}function rl(n,e){function i(){const o=n.bucket,a=n.fullPath,h=new tt(o,a);return e._makeStorageReference(h)}Object.defineProperty(n,"ref",{get:i})}function ol(n,e,i){const o={};o.type="file";const a=i.length;for(let h=0;h<a;h++){const c=i[h];o[c.local]=c.xform(o,e[c.server])}return rl(o,n),o}function Ri(n,e,i){const o=Ii(e);return o===null?null:ol(n,o,i)}function al(n,e,i,o){const a=Ii(e);if(a===null||!Oe(a.downloadTokens))return null;const h=a.downloadTokens;if(h.length===0)return null;const c=encodeURIComponent;return h.split(",").map(T=>{const S=n.bucket,I=n.fullPath,C="/b/"+c(S)+"/o/"+c(I),O=jt(C,i,o),k=bi({alt:"media",token:T});return O+k})[0]}function Ci(n,e){const i={},o=e.length;for(let a=0;a<o;a++){const h=e[a];h.writable&&(i[h.server]=n[h.local])}return JSON.stringify(i)}class Nt{constructor(e,i,o,a){this.url=e,this.method=i,this.handler=o,this.timeout=a,this.urlParams={},this.headers={},this.body=null,this.errorHandler=null,this.progressCallback=null,this.successCodes=[200],this.additionalRetryCodes=[]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ot(n){if(!n)throw bn()}function vn(n,e){function i(o,a){const h=Ri(n,a,e);return ot(h!==null),h}return i}function ll(n,e){function i(o,a){const h=Ri(n,a,e);return ot(h!==null),al(h,a,n.host,n._protocol)}return i}function re(n){function e(i,o){let a;return i.getStatus()===401?i.getErrorText().includes("Firebase App Check token is invalid")?a=Sa():a=Ia():i.getStatus()===402?a=Ea(n.bucket):i.getStatus()===403?a=Aa(n.path):a=o,a.status=i.getStatus(),a.serverResponse=o.serverResponse,a}return e}function Tn(n){const e=re(n);function i(o,a){let h=e(o,a);return o.getStatus()===404&&(h=Ta(n.path)),h.serverResponse=a.serverResponse,h}return i}function hl(n,e,i){const o=e.fullServerUrl(),a=jt(o,n.host,n._protocol),h="GET",c=n.maxOperationRetryTime,w=new Nt(a,h,vn(n,i),c);return w.errorHandler=Tn(e),w}function cl(n,e,i){const o=e.fullServerUrl(),a=jt(o,n.host,n._protocol),h="GET",c=n.maxOperationRetryTime,w=new Nt(a,h,ll(n,i),c);return w.errorHandler=Tn(e),w}function ul(n,e){const i=e.fullServerUrl(),o=jt(i,n.host,n._protocol),a="DELETE",h=n.maxOperationRetryTime;function c(v,T){}const w=new Nt(o,a,c,h);return w.successCodes=[200,204],w.errorHandler=Tn(e),w}function fl(n,e){return n&&n.contentType||e&&e.type()||"application/octet-stream"}function ki(n,e,i){const o=Object.assign({},i);return o.fullPath=n.path,o.size=e.size(),o.contentType||(o.contentType=fl(null,e)),o}function dl(n,e,i,o,a){const h=e.bucketOnlyServerUrl(),c={"X-Goog-Upload-Protocol":"multipart"};function w(){let N="";for(let L=0;L<2;L++)N=N+Math.random().toString().slice(2);return N}const v=w();c["Content-Type"]="multipart/related; boundary="+v;const T=ki(e,o,a),S=Ci(T,i),I="--"+v+`\r
Content-Type: application/json; charset=utf-8\r
\r
`+S+`\r
--`+v+`\r
Content-Type: `+T.contentType+`\r
\r
`,C=`\r
--`+v+"--",O=gt.getBlob(I,o,C);if(O===null)throw yi();const k={name:T.fullPath},D=jt(h,n.host,n._protocol),A="POST",z=n.maxUploadRetryTime,q=new Nt(D,A,vn(n,i),z);return q.urlParams=k,q.headers=c,q.body=O.uploadData(),q.errorHandler=re(e),q}class Ae{constructor(e,i,o,a){this.current=e,this.total=i,this.finalized=!!o,this.metadata=a||null}}function En(n,e){let i=null;try{i=n.getResponseHeader("X-Goog-Upload-Status")}catch{ot(!1)}return ot(!!i&&(e||["active"]).indexOf(i)!==-1),i}function pl(n,e,i,o,a){const h=e.bucketOnlyServerUrl(),c=ki(e,o,a),w={name:c.fullPath},v=jt(h,n.host,n._protocol),T="POST",S={"X-Goog-Upload-Protocol":"resumable","X-Goog-Upload-Command":"start","X-Goog-Upload-Header-Content-Length":`${o.size()}`,"X-Goog-Upload-Header-Content-Type":c.contentType,"Content-Type":"application/json; charset=utf-8"},I=Ci(c,i),C=n.maxUploadRetryTime;function O(D){En(D);let A;try{A=D.getResponseHeader("X-Goog-Upload-URL")}catch{ot(!1)}return ot(Oe(A)),A}const k=new Nt(v,T,O,C);return k.urlParams=w,k.headers=S,k.body=I,k.errorHandler=re(e),k}function gl(n,e,i,o){const a={"X-Goog-Upload-Command":"query"};function h(T){const S=En(T,["active","final"]);let I=null;try{I=T.getResponseHeader("X-Goog-Upload-Size-Received")}catch{ot(!1)}I||ot(!1);const C=Number(I);return ot(!isNaN(C)),new Ae(C,o.size(),S==="final")}const c="POST",w=n.maxUploadRetryTime,v=new Nt(i,c,h,w);return v.headers=a,v.errorHandler=re(e),v}const zs=256*1024;function ml(n,e,i,o,a,h,c,w){const v=new Ae(0,0);if(c?(v.current=c.current,v.total=c.total):(v.current=0,v.total=o.size()),o.size()!==v.total)throw Oa();const T=v.total-v.current;let S=T;a>0&&(S=Math.min(S,a));const I=v.current,C=I+S;let O="";S===0?O="finalize":T===S?O="upload, finalize":O="upload";const k={"X-Goog-Upload-Command":O,"X-Goog-Upload-Offset":`${v.current}`},D=o.slice(I,C);if(D===null)throw yi();function A(L,G){const F=En(L,["active","final"]),g=v.current+S,u=o.size();let d;return F==="final"?d=vn(e,h)(L,G):d=null,new Ae(g,u,F==="final",d)}const z="POST",q=e.maxUploadRetryTime,N=new Nt(i,z,A,q);return N.headers=k,N.body=D.uploadData(),N.progressCallback=w||null,N.errorHandler=re(n),N}const Z={RUNNING:"running",PAUSED:"paused",SUCCESS:"success",CANCELED:"canceled",ERROR:"error"};function ln(n){switch(n){case"running":case"pausing":case"canceling":return Z.RUNNING;case"paused":return Z.PAUSED;case"success":return Z.SUCCESS;case"canceled":return Z.CANCELED;case"error":return Z.ERROR;default:return Z.ERROR}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yl{constructor(e,i,o){if(Ba(e)||i!=null||o!=null)this.next=e,this.error=i??void 0,this.complete=o??void 0;else{const h=e;this.next=h.next,this.error=h.error,this.complete=h.complete}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lt(n){return(...e)=>{Promise.resolve().then(()=>n(...e))}}class _l{constructor(){this.sent_=!1,this.xhr_=new XMLHttpRequest,this.initXhr(),this.errorCode_=Ct.NO_ERROR,this.sendPromise_=new Promise(e=>{this.xhr_.addEventListener("abort",()=>{this.errorCode_=Ct.ABORT,e()}),this.xhr_.addEventListener("error",()=>{this.errorCode_=Ct.NETWORK_ERROR,e()}),this.xhr_.addEventListener("load",()=>{e()})})}send(e,i,o,a,h){if(this.sent_)throw ne("cannot .send() more than once");if(hi(e)&&o&&(this.xhr_.withCredentials=!0),this.sent_=!0,this.xhr_.open(i,e,!0),h!==void 0)for(const c in h)h.hasOwnProperty(c)&&this.xhr_.setRequestHeader(c,h[c].toString());return a!==void 0?this.xhr_.send(a):this.xhr_.send(),this.sendPromise_}getErrorCode(){if(!this.sent_)throw ne("cannot .getErrorCode() before sending");return this.errorCode_}getStatus(){if(!this.sent_)throw ne("cannot .getStatus() before sending");try{return this.xhr_.status}catch{return-1}}getResponse(){if(!this.sent_)throw ne("cannot .getResponse() before sending");return this.xhr_.response}getErrorText(){if(!this.sent_)throw ne("cannot .getErrorText() before sending");return this.xhr_.statusText}abort(){this.xhr_.abort()}getResponseHeader(e){return this.xhr_.getResponseHeader(e)}addUploadProgressListener(e){this.xhr_.upload!=null&&this.xhr_.upload.addEventListener("progress",e)}removeUploadProgressListener(e){this.xhr_.upload!=null&&this.xhr_.upload.removeEventListener("progress",e)}}class bl extends _l{initXhr(){this.xhr_.responseType="text"}}function At(){return new bl}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wl{isExponentialBackoffExpired(){return this.sleepTime>this.maxSleepTime}constructor(e,i,o=null){this._transferred=0,this._needToFetchStatus=!1,this._needToFetchMetadata=!1,this._observers=[],this._error=void 0,this._uploadUrl=void 0,this._request=void 0,this._chunkMultiplier=1,this._resolve=void 0,this._reject=void 0,this._ref=e,this._blob=i,this._metadata=o,this._mappings=Ai(),this._resumable=this._shouldDoResumable(this._blob),this._state="running",this._errorHandler=a=>{if(this._request=void 0,this._chunkMultiplier=1,a._codeEquals(M.CANCELED))this._needToFetchStatus=!0,this.completeTransitions_();else{const h=this.isExponentialBackoffExpired();if(wi(a.status,[]))if(h)a=gi();else{this.sleepTime=Math.max(this.sleepTime*2,va),this._needToFetchStatus=!0,this.completeTransitions_();return}this._error=a,this._transition("error")}},this._metadataErrorHandler=a=>{this._request=void 0,a._codeEquals(M.CANCELED)?this.completeTransitions_():(this._error=a,this._transition("error"))},this.sleepTime=0,this.maxSleepTime=this._ref.storage.maxUploadRetryTime,this._promise=new Promise((a,h)=>{this._resolve=a,this._reject=h,this._start()}),this._promise.then(null,()=>{})}_makeProgressCallback(){const e=this._transferred;return i=>this._updateProgress(e+i)}_shouldDoResumable(e){return e.size()>256*1024}_start(){this._state==="running"&&this._request===void 0&&(this._resumable?this._uploadUrl===void 0?this._createResumable():this._needToFetchStatus?this._fetchStatus():this._needToFetchMetadata?this._fetchMetadata():this.pendingTimeout=setTimeout(()=>{this.pendingTimeout=void 0,this._continueUpload()},this.sleepTime):this._oneShotUpload())}_resolveToken(e){Promise.all([this._ref.storage._getAuthToken(),this._ref.storage._getAppCheckToken()]).then(([i,o])=>{switch(this._state){case"running":e(i,o);break;case"canceling":this._transition("canceled");break;case"pausing":this._transition("paused");break}})}_createResumable(){this._resolveToken((e,i)=>{const o=pl(this._ref.storage,this._ref._location,this._mappings,this._blob,this._metadata),a=this._ref.storage._makeRequest(o,At,e,i);this._request=a,a.getPromise().then(h=>{this._request=void 0,this._uploadUrl=h,this._needToFetchStatus=!1,this.completeTransitions_()},this._errorHandler)})}_fetchStatus(){const e=this._uploadUrl;this._resolveToken((i,o)=>{const a=gl(this._ref.storage,this._ref._location,e,this._blob),h=this._ref.storage._makeRequest(a,At,i,o);this._request=h,h.getPromise().then(c=>{c=c,this._request=void 0,this._updateProgress(c.current),this._needToFetchStatus=!1,c.finalized&&(this._needToFetchMetadata=!0),this.completeTransitions_()},this._errorHandler)})}_continueUpload(){const e=zs*this._chunkMultiplier,i=new Ae(this._transferred,this._blob.size()),o=this._uploadUrl;this._resolveToken((a,h)=>{let c;try{c=ml(this._ref._location,this._ref.storage,o,this._blob,e,this._mappings,i,this._makeProgressCallback())}catch(v){this._error=v,this._transition("error");return}const w=this._ref.storage._makeRequest(c,At,a,h,!1);this._request=w,w.getPromise().then(v=>{this._increaseMultiplier(),this._request=void 0,this._updateProgress(v.current),v.finalized?(this._metadata=v.metadata,this._transition("success")):this.completeTransitions_()},this._errorHandler)})}_increaseMultiplier(){zs*this._chunkMultiplier*2<32*1024*1024&&(this._chunkMultiplier*=2)}_fetchMetadata(){this._resolveToken((e,i)=>{const o=hl(this._ref.storage,this._ref._location,this._mappings),a=this._ref.storage._makeRequest(o,At,e,i);this._request=a,a.getPromise().then(h=>{this._request=void 0,this._metadata=h,this._transition("success")},this._metadataErrorHandler)})}_oneShotUpload(){this._resolveToken((e,i)=>{const o=dl(this._ref.storage,this._ref._location,this._mappings,this._blob,this._metadata),a=this._ref.storage._makeRequest(o,At,e,i);this._request=a,a.getPromise().then(h=>{this._request=void 0,this._metadata=h,this._updateProgress(this._blob.size()),this._transition("success")},this._errorHandler)})}_updateProgress(e){const i=this._transferred;this._transferred=e,this._transferred!==i&&this._notifyObservers()}_transition(e){if(this._state!==e)switch(e){case"canceling":case"pausing":this._state=e,this._request!==void 0?this._request.cancel():this.pendingTimeout&&(clearTimeout(this.pendingTimeout),this.pendingTimeout=void 0,this.completeTransitions_());break;case"running":const i=this._state==="paused";this._state=e,i&&(this._notifyObservers(),this._start());break;case"paused":this._state=e,this._notifyObservers();break;case"canceled":this._error=mi(),this._state=e,this._notifyObservers();break;case"error":this._state=e,this._notifyObservers();break;case"success":this._state=e,this._notifyObservers();break}}completeTransitions_(){switch(this._state){case"pausing":this._transition("paused");break;case"canceling":this._transition("canceled");break;case"running":this._start();break}}get snapshot(){const e=ln(this._state);return{bytesTransferred:this._transferred,totalBytes:this._blob.size(),state:e,metadata:this._metadata,task:this,ref:this._ref}}on(e,i,o,a){const h=new yl(i||void 0,o||void 0,a||void 0);return this._addObserver(h),()=>{this._removeObserver(h)}}then(e,i){return this._promise.then(e,i)}catch(e){return this.then(null,e)}_addObserver(e){this._observers.push(e),this._notifyObserver(e)}_removeObserver(e){const i=this._observers.indexOf(e);i!==-1&&this._observers.splice(i,1)}_notifyObservers(){this._finishPromise(),this._observers.slice().forEach(i=>{this._notifyObserver(i)})}_finishPromise(){if(this._resolve!==void 0){let e=!0;switch(ln(this._state)){case Z.SUCCESS:Lt(this._resolve.bind(null,this.snapshot))();break;case Z.CANCELED:case Z.ERROR:const i=this._reject;Lt(i.bind(null,this._error))();break;default:e=!1;break}e&&(this._resolve=void 0,this._reject=void 0)}}_notifyObserver(e){switch(ln(this._state)){case Z.RUNNING:case Z.PAUSED:e.next&&Lt(e.next.bind(e,this.snapshot))();break;case Z.SUCCESS:e.complete&&Lt(e.complete.bind(e))();break;case Z.CANCELED:case Z.ERROR:e.error&&Lt(e.error.bind(e,this._error))();break;default:e.error&&Lt(e.error.bind(e,this._error))()}}resume(){const e=this._state==="paused"||this._state==="pausing";return e&&this._transition("running"),e}pause(){const e=this._state==="running";return e&&this._transition("pausing"),e}cancel(){const e=this._state==="running"||this._state==="pausing";return e&&this._transition("canceling"),e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kt{constructor(e,i){this._service=e,i instanceof tt?this._location=i:this._location=tt.makeFromUrl(i,e.host)}toString(){return"gs://"+this._location.bucket+"/"+this._location.path}_newRef(e,i){return new kt(e,i)}get root(){const e=new tt(this._location.bucket,"");return this._newRef(this._service,e)}get bucket(){return this._location.bucket}get fullPath(){return this._location.path}get name(){return Si(this._location.path)}get storage(){return this._service}get parent(){const e=el(this._location.path);if(e===null)return null;const i=new tt(this._location.bucket,e);return new kt(this._service,i)}_throwIfRoot(e){if(this._location.path==="")throw Na(e)}}function vl(n,e,i){return n._throwIfRoot("uploadBytesResumable"),new wl(n,new gt(e),i)}function Tl(n){n._throwIfRoot("getDownloadURL");const e=cl(n.storage,n._location,Ai());return n.storage.makeRequestWithTokens(e,At).then(i=>{if(i===null)throw Da();return i})}function El(n){n._throwIfRoot("deleteObject");const e=ul(n.storage,n._location);return n.storage.makeRequestWithTokens(e,At)}function Il(n,e){const i=nl(n._location.path,e),o=new tt(n._location.bucket,i);return new kt(n.storage,o)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sl(n){return/^[A-Za-z]+:\/\//.test(n)}function Al(n,e){return new kt(n,e)}function Oi(n,e){if(n instanceof In){const i=n;if(i._bucket==null)throw ka();const o=new kt(i,i._bucket);return e!=null?Oi(o,e):o}else return e!==void 0?Il(n,e):n}function Rl(n,e){if(e&&Sl(e)){if(n instanceof In)return Al(n,e);throw mn("To use ref(service, url), the first argument must be a Storage instance.")}else return Oi(n,e)}function qs(n,e){const i=e==null?void 0:e[pi];return i==null?null:tt.makeFromBucketSpec(i,n)}function Cl(n,e,i,o={}){n.host=`${e}:${i}`;const a=hi(e);a&&io(`https://${n.host}/b`),n._isUsingEmulator=!0,n._protocol=a?"https":"http";const{mockUserToken:h}=o;h&&(n._overrideAuthToken=typeof h=="string"?h:Vr(h,n.app.options.projectId))}class In{constructor(e,i,o,a,h,c=!1){this.app=e,this._authProvider=i,this._appCheckProvider=o,this._url=a,this._firebaseVersion=h,this._isUsingEmulator=c,this._bucket=null,this._host=di,this._protocol="https",this._appId=null,this._deleted=!1,this._maxOperationRetryTime=ba,this._maxUploadRetryTime=wa,this._requests=new Set,a!=null?this._bucket=tt.makeFromBucketSpec(a,this._host):this._bucket=qs(this._host,this.app.options)}get host(){return this._host}set host(e){this._host=e,this._url!=null?this._bucket=tt.makeFromBucketSpec(this._url,e):this._bucket=qs(e,this.app.options)}get maxUploadRetryTime(){return this._maxUploadRetryTime}set maxUploadRetryTime(e){Hs("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e}get maxOperationRetryTime(){return this._maxOperationRetryTime}set maxOperationRetryTime(e){Hs("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e}async _getAuthToken(){if(this._overrideAuthToken)return this._overrideAuthToken;const e=this._authProvider.getImmediate({optional:!0});if(e){const i=await e.getToken();if(i!==null)return i.accessToken}return null}async _getAppCheckToken(){if(Vo(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=this._appCheckProvider.getImmediate({optional:!0});return e?(await e.getToken()).token:null}_delete(){return this._deleted||(this._deleted=!0,this._requests.forEach(e=>e.cancel()),this._requests.clear()),Promise.resolve()}_makeStorageReference(e){return new kt(this,e)}_makeRequest(e,i,o,a,h=!0){if(this._deleted)return new xa(_i());{const c=Va(e,this._appId,o,a,i,this._firebaseVersion,h,this._isUsingEmulator);return this._requests.add(c),c.getPromise().then(()=>this._requests.delete(c),()=>this._requests.delete(c)),c}}async makeRequestWithTokens(e,i){const[o,a]=await Promise.all([this._getAuthToken(),this._getAppCheckToken()]);return this._makeRequest(e,i,o,a).getPromise()}}const Vs="@firebase/storage",Gs="0.14.2";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Di="storage";function ac(n,e,i){return n=Pt(n),vl(n,e,i)}function lc(n){return n=Pt(n),Tl(n)}function hc(n){return n=Pt(n),El(n)}function cc(n,e){return n=Pt(n),Rl(n,e)}function uc(n=Yo(),e){n=Pt(n);const o=_n(n,Di).getImmediate({identifier:e}),a=zr("storage");return a&&kl(o,...a),o}function kl(n,e,i,o={}){Cl(n,e,i,o)}function Ol(n,{instanceIdentifier:e}){const i=n.getProvider("app").getImmediate(),o=n.getProvider("auth-internal"),a=n.getProvider("app-check-internal");return new In(i,o,a,e,Xo)}function Dl(){yt(new at(Di,Ol,"PUBLIC").setMultipleInstances(!0)),rt(Vs,Gs,""),rt(Vs,Gs,"esm2020")}Dl();const Pi="@firebase/installations",Sn="0.6.21";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ni=1e4,xi=`w:${Sn}`,Ui="FIS_v2",Pl="https://firebaseinstallations.googleapis.com/v1",Nl=3600*1e3,xl="installations",Ul="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ml={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},Ot=new ke(xl,Ul,Ml);function Mi(n){return n instanceof _t&&n.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Li({projectId:n}){return`${Pl}/projects/${n}/installations`}function Bi(n){return{token:n.token,requestStatus:2,expiresIn:Bl(n.expiresIn),creationTime:Date.now()}}async function ji(n,e){const o=(await e.json()).error;return Ot.create("request-failed",{requestName:n,serverCode:o.code,serverMessage:o.message,serverStatus:o.status})}function Fi({apiKey:n}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":n})}function Ll(n,{refreshToken:e}){const i=Fi(n);return i.append("Authorization",jl(e)),i}async function $i(n){const e=await n();return e.status>=500&&e.status<600?n():e}function Bl(n){return Number(n.replace("s","000"))}function jl(n){return`${Ui} ${n}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fl({appConfig:n,heartbeatServiceProvider:e},{fid:i}){const o=Li(n),a=Fi(n),h=e.getImmediate({optional:!0});if(h){const T=await h.getHeartbeatsHeader();T&&a.append("x-firebase-client",T)}const c={fid:i,authVersion:Ui,appId:n.appId,sdkVersion:xi},w={method:"POST",headers:a,body:JSON.stringify(c)},v=await $i(()=>fetch(o,w));if(v.ok){const T=await v.json();return{fid:T.fid||i,registrationStatus:2,refreshToken:T.refreshToken,authToken:Bi(T.authToken)}}else throw await ji("Create Installation",v)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hi(n){return new Promise(e=>{setTimeout(e,n)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $l(n){return btoa(String.fromCharCode(...n)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hl=/^[cdef][\w-]{21}$/,yn="";function zl(){try{const n=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(n),n[0]=112+n[0]%16;const i=ql(n);return Hl.test(i)?i:yn}catch{return yn}}function ql(n){return $l(n).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function De(n){return`${n.appName}!${n.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zi=new Map;function qi(n,e){const i=De(n);Vi(i,e),Vl(i,e)}function Vi(n,e){const i=zi.get(n);if(i)for(const o of i)o(e)}function Vl(n,e){const i=Gl();i&&i.postMessage({key:n,fid:e}),Wl()}let Rt=null;function Gl(){return!Rt&&"BroadcastChannel"in self&&(Rt=new BroadcastChannel("[Firebase] FID Change"),Rt.onmessage=n=>{Vi(n.data.key,n.data.fid)}),Rt}function Wl(){zi.size===0&&Rt&&(Rt.close(),Rt=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xl="firebase-installations-database",Kl=1,Dt="firebase-installations-store";let hn=null;function An(){return hn||(hn=ni(Xl,Kl,{upgrade:(n,e)=>{switch(e){case 0:n.createObjectStore(Dt)}}})),hn}async function Re(n,e){const i=De(n),a=(await An()).transaction(Dt,"readwrite"),h=a.objectStore(Dt),c=await h.get(i);return await h.put(e,i),await a.done,(!c||c.fid!==e.fid)&&qi(n,e.fid),e}async function Gi(n){const e=De(n),o=(await An()).transaction(Dt,"readwrite");await o.objectStore(Dt).delete(e),await o.done}async function Pe(n,e){const i=De(n),a=(await An()).transaction(Dt,"readwrite"),h=a.objectStore(Dt),c=await h.get(i),w=e(c);return w===void 0?await h.delete(i):await h.put(w,i),await a.done,w&&(!c||c.fid!==w.fid)&&qi(n,w.fid),w}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rn(n){let e;const i=await Pe(n.appConfig,o=>{const a=Yl(o),h=Jl(n,a);return e=h.registrationPromise,h.installationEntry});return i.fid===yn?{installationEntry:await e}:{installationEntry:i,registrationPromise:e}}function Yl(n){const e=n||{fid:zl(),registrationStatus:0};return Wi(e)}function Jl(n,e){if(e.registrationStatus===0){if(!navigator.onLine){const a=Promise.reject(Ot.create("app-offline"));return{installationEntry:e,registrationPromise:a}}const i={fid:e.fid,registrationStatus:1,registrationTime:Date.now()},o=Zl(n,i);return{installationEntry:i,registrationPromise:o}}else return e.registrationStatus===1?{installationEntry:e,registrationPromise:Ql(n)}:{installationEntry:e}}async function Zl(n,e){try{const i=await Fl(n,e);return Re(n.appConfig,i)}catch(i){throw Mi(i)&&i.customData.serverCode===409?await Gi(n.appConfig):await Re(n.appConfig,{fid:e.fid,registrationStatus:0}),i}}async function Ql(n){let e=await Ws(n.appConfig);for(;e.registrationStatus===1;)await Hi(100),e=await Ws(n.appConfig);if(e.registrationStatus===0){const{installationEntry:i,registrationPromise:o}=await Rn(n);return o||i}return e}function Ws(n){return Pe(n,e=>{if(!e)throw Ot.create("installation-not-found");return Wi(e)})}function Wi(n){return th(n)?{fid:n.fid,registrationStatus:0}:n}function th(n){return n.registrationStatus===1&&n.registrationTime+Ni<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function eh({appConfig:n,heartbeatServiceProvider:e},i){const o=nh(n,i),a=Ll(n,i),h=e.getImmediate({optional:!0});if(h){const T=await h.getHeartbeatsHeader();T&&a.append("x-firebase-client",T)}const c={installation:{sdkVersion:xi,appId:n.appId}},w={method:"POST",headers:a,body:JSON.stringify(c)},v=await $i(()=>fetch(o,w));if(v.ok){const T=await v.json();return Bi(T)}else throw await ji("Generate Auth Token",v)}function nh(n,{fid:e}){return`${Li(n)}/${e}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Cn(n,e=!1){let i;const o=await Pe(n.appConfig,h=>{if(!Xi(h))throw Ot.create("not-registered");const c=h.authToken;if(!e&&rh(c))return h;if(c.requestStatus===1)return i=sh(n,e),h;{if(!navigator.onLine)throw Ot.create("app-offline");const w=ah(h);return i=ih(n,w),w}});return i?await i:o.authToken}async function sh(n,e){let i=await Xs(n.appConfig);for(;i.authToken.requestStatus===1;)await Hi(100),i=await Xs(n.appConfig);const o=i.authToken;return o.requestStatus===0?Cn(n,e):o}function Xs(n){return Pe(n,e=>{if(!Xi(e))throw Ot.create("not-registered");const i=e.authToken;return lh(i)?{...e,authToken:{requestStatus:0}}:e})}async function ih(n,e){try{const i=await eh(n,e),o={...e,authToken:i};return await Re(n.appConfig,o),i}catch(i){if(Mi(i)&&(i.customData.serverCode===401||i.customData.serverCode===404))await Gi(n.appConfig);else{const o={...e,authToken:{requestStatus:0}};await Re(n.appConfig,o)}throw i}}function Xi(n){return n!==void 0&&n.registrationStatus===2}function rh(n){return n.requestStatus===2&&!oh(n)}function oh(n){const e=Date.now();return e<n.creationTime||n.creationTime+n.expiresIn<e+Nl}function ah(n){const e={requestStatus:1,requestTime:Date.now()};return{...n,authToken:e}}function lh(n){return n.requestStatus===1&&n.requestTime+Ni<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function hh(n){const e=n,{installationEntry:i,registrationPromise:o}=await Rn(e);return o?o.catch(console.error):Cn(e).catch(console.error),i.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ch(n,e=!1){const i=n;return await uh(i),(await Cn(i,e)).token}async function uh(n){const{registrationPromise:e}=await Rn(n);e&&await e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fh(n){if(!n||!n.options)throw cn("App Configuration");if(!n.name)throw cn("App Name");const e=["projectId","apiKey","appId"];for(const i of e)if(!n.options[i])throw cn(i);return{appName:n.name,projectId:n.options.projectId,apiKey:n.options.apiKey,appId:n.options.appId}}function cn(n){return Ot.create("missing-app-config-values",{valueName:n})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ki="installations",dh="installations-internal",ph=n=>{const e=n.getProvider("app").getImmediate(),i=fh(e),o=_n(e,"heartbeat");return{app:e,appConfig:i,heartbeatServiceProvider:o,_delete:()=>Promise.resolve()}},gh=n=>{const e=n.getProvider("app").getImmediate(),i=_n(e,Ki).getImmediate();return{getId:()=>hh(i),getToken:a=>ch(i,a)}};function mh(){yt(new at(Ki,ph,"PUBLIC")),yt(new at(dh,gh,"PRIVATE"))}mh();rt(Pi,Sn);rt(Pi,Sn,"esm2020");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ks="analytics",yh="firebase_id",_h="origin",bh=60*1e3,wh="https://firebase.googleapis.com/v1alpha/projects/-/apps/{app-id}/webConfig",kn="https://www.googletagmanager.com/gtag/js";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Y=new ci("@firebase/analytics");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vh={"already-exists":"A Firebase Analytics instance with the appId {$id}  already exists. Only one Firebase Analytics instance can be created for each appId.","already-initialized":"initializeAnalytics() cannot be called again with different options than those it was initially called with. It can be called again with the same options to return the existing instance, or getAnalytics() can be used to get a reference to the already-initialized instance.","already-initialized-settings":"Firebase Analytics has already been initialized.settings() must be called before initializing any Analytics instanceor it will have no effect.","interop-component-reg-failed":"Firebase Analytics Interop Component failed to instantiate: {$reason}","invalid-analytics-context":"Firebase Analytics is not supported in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","indexeddb-unavailable":"IndexedDB unavailable or restricted in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","fetch-throttle":"The config fetch request timed out while in an exponential backoff state. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.","config-fetch-failed":"Dynamic config fetch failed: [{$httpStatus}] {$responseMessage}","no-api-key":'The "apiKey" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid API key.',"no-app-id":'The "appId" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid app ID.',"no-client-id":'The "client_id" field is empty.',"invalid-gtag-resource":"Trusted Types detected an invalid gtag resource: {$gtagURL}."},et=new ke("analytics","Analytics",vh);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Th(n){if(!n.startsWith(kn)){const e=et.create("invalid-gtag-resource",{gtagURL:n});return Y.warn(e.message),""}return n}function Yi(n){return Promise.all(n.map(e=>e.catch(i=>i)))}function Eh(n,e){let i;return window.trustedTypes&&(i=window.trustedTypes.createPolicy(n,e)),i}function Ih(n,e){const i=Eh("firebase-js-sdk-policy",{createScriptURL:Th}),o=document.createElement("script"),a=`${kn}?l=${n}&id=${e}`;o.src=i?i==null?void 0:i.createScriptURL(a):a,o.async=!0,document.head.appendChild(o)}function Sh(n){let e=[];return Array.isArray(window[n])?e=window[n]:window[n]=e,e}async function Ah(n,e,i,o,a,h){const c=o[a];try{if(c)await e[c];else{const v=(await Yi(i)).find(T=>T.measurementId===a);v&&await e[v.appId]}}catch(w){Y.error(w)}n("config",a,h)}async function Rh(n,e,i,o,a){try{let h=[];if(a&&a.send_to){let c=a.send_to;Array.isArray(c)||(c=[c]);const w=await Yi(i);for(const v of c){const T=w.find(I=>I.measurementId===v),S=T&&e[T.appId];if(S)h.push(S);else{h=[];break}}}h.length===0&&(h=Object.values(e)),await Promise.all(h),n("event",o,a||{})}catch(h){Y.error(h)}}function Ch(n,e,i,o){async function a(h,...c){try{if(h==="event"){const[w,v]=c;await Rh(n,e,i,w,v)}else if(h==="config"){const[w,v]=c;await Ah(n,e,i,o,w,v)}else if(h==="consent"){const[w,v]=c;n("consent",w,v)}else if(h==="get"){const[w,v,T]=c;n("get",w,v,T)}else if(h==="set"){const[w]=c;n("set",w)}else n(h,...c)}catch(w){Y.error(w)}}return a}function kh(n,e,i,o,a){let h=function(...c){window[o].push(arguments)};return window[a]&&typeof window[a]=="function"&&(h=window[a]),window[a]=Ch(h,n,e,i),{gtagCore:h,wrappedGtag:window[a]}}function Oh(n){const e=window.document.getElementsByTagName("script");for(const i of Object.values(e))if(i.src&&i.src.includes(kn)&&i.src.includes(n))return i;return null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dh=30,Ph=1e3;class Nh{constructor(e={},i=Ph){this.throttleMetadata=e,this.intervalMillis=i}getThrottleMetadata(e){return this.throttleMetadata[e]}setThrottleMetadata(e,i){this.throttleMetadata[e]=i}deleteThrottleMetadata(e){delete this.throttleMetadata[e]}}const Ji=new Nh;function xh(n){return new Headers({Accept:"application/json","x-goog-api-key":n})}async function Uh(n){var c;const{appId:e,apiKey:i}=n,o={method:"GET",headers:xh(i)},a=wh.replace("{app-id}",e),h=await fetch(a,o);if(h.status!==200&&h.status!==304){let w="";try{const v=await h.json();(c=v.error)!=null&&c.message&&(w=v.error.message)}catch{}throw et.create("config-fetch-failed",{httpStatus:h.status,responseMessage:w})}return h.json()}async function Mh(n,e=Ji,i){const{appId:o,apiKey:a,measurementId:h}=n.options;if(!o)throw et.create("no-app-id");if(!a){if(h)return{measurementId:h,appId:o};throw et.create("no-api-key")}const c=e.getThrottleMetadata(o)||{backoffCount:0,throttleEndTimeMillis:Date.now()},w=new jh;return setTimeout(async()=>{w.abort()},bh),Zi({appId:o,apiKey:a,measurementId:h},c,w,e)}async function Zi(n,{throttleEndTimeMillis:e,backoffCount:i},o,a=Ji){var w;const{appId:h,measurementId:c}=n;try{await Lh(o,e)}catch(v){if(c)return Y.warn(`Timed out fetching this Firebase app's measurement ID from the server. Falling back to the measurement ID ${c} provided in the "measurementId" field in the local Firebase config. [${v==null?void 0:v.message}]`),{appId:h,measurementId:c};throw v}try{const v=await Uh(n);return a.deleteThrottleMetadata(h),v}catch(v){const T=v;if(!Bh(T)){if(a.deleteThrottleMetadata(h),c)return Y.warn(`Failed to fetch this Firebase app's measurement ID from the server. Falling back to the measurement ID ${c} provided in the "measurementId" field in the local Firebase config. [${T==null?void 0:T.message}]`),{appId:h,measurementId:c};throw v}const S=Number((w=T==null?void 0:T.customData)==null?void 0:w.httpStatus)===503?xs(i,a.intervalMillis,Dh):xs(i,a.intervalMillis),I={throttleEndTimeMillis:Date.now()+S,backoffCount:i+1};return a.setThrottleMetadata(h,I),Y.debug(`Calling attemptFetch again in ${S} millis`),Zi(n,I,o,a)}}function Lh(n,e){return new Promise((i,o)=>{const a=Math.max(e-Date.now(),0),h=setTimeout(i,a);n.addEventListener(()=>{clearTimeout(h),o(et.create("fetch-throttle",{throttleEndTimeMillis:e}))})})}function Bh(n){if(!(n instanceof _t)||!n.customData)return!1;const e=Number(n.customData.httpStatus);return e===429||e===500||e===503||e===504}class jh{constructor(){this.listeners=[]}addEventListener(e){this.listeners.push(e)}abort(){this.listeners.forEach(e=>e())}}async function Fh(n,e,i,o,a){if(a&&a.global){n("event",i,o);return}else{const h=await e,c={...o,send_to:h};n("event",i,c)}}async function $h(n,e,i,o){if(o&&o.global){const a={};for(const h of Object.keys(i))a[`user_properties.${h}`]=i[h];return n("set",a),Promise.resolve()}else{const a=await e;n("config",a,{update:!0,user_properties:i})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Hh(){if(ai())try{await li()}catch(n){return Y.warn(et.create("indexeddb-unavailable",{errorInfo:n==null?void 0:n.toString()}).message),!1}else return Y.warn(et.create("indexeddb-unavailable",{errorInfo:"IndexedDB is not available in this environment."}).message),!1;return!0}async function zh(n,e,i,o,a,h,c){const w=Mh(n);w.then(C=>{i[C.measurementId]=C.appId,n.options.measurementId&&C.measurementId!==n.options.measurementId&&Y.warn(`The measurement ID in the local Firebase config (${n.options.measurementId}) does not match the measurement ID fetched from the server (${C.measurementId}). To ensure analytics events are always sent to the correct Analytics property, update the measurement ID field in the local config or remove it from the local config.`)}).catch(C=>Y.error(C)),e.push(w);const v=Hh().then(C=>{if(C)return o.getId()}),[T,S]=await Promise.all([w,v]);Oh(h)||Ih(h,T.measurementId),a("js",new Date);const I=(c==null?void 0:c.config)??{};return I[_h]="firebase",I.update=!0,S!=null&&(I[yh]=S),a("config",T.measurementId,I),T.measurementId}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qh{constructor(e){this.app=e}_delete(){return delete Bt[this.app.options.appId],Promise.resolve()}}let Bt={},Ys=[];const Js={};let un="dataLayer",Vh="gtag",Zs,On,Qs=!1;function Gh(){const n=[];if(Wr()&&n.push("This is a browser extension environment."),Xr()||n.push("Cookies are not available."),n.length>0){const e=n.map((o,a)=>`(${a+1}) ${o}`).join(" "),i=et.create("invalid-analytics-context",{errorInfo:e});Y.warn(i.message)}}function Wh(n,e,i){Gh();const o=n.options.appId;if(!o)throw et.create("no-app-id");if(!n.options.apiKey)if(n.options.measurementId)Y.warn(`The "apiKey" field is empty in the local Firebase config. This is needed to fetch the latest measurement ID for this Firebase app. Falling back to the measurement ID ${n.options.measurementId} provided in the "measurementId" field in the local Firebase config.`);else throw et.create("no-api-key");if(Bt[o]!=null)throw et.create("already-exists",{id:o});if(!Qs){Sh(un);const{wrappedGtag:h,gtagCore:c}=kh(Bt,Ys,Js,un,Vh);On=h,Zs=c,Qs=!0}return Bt[o]=zh(n,Ys,Js,e,Zs,un,i),new qh(n)}function Qi(n,e,i){n=Pt(n),$h(On,Bt[n.app.options.appId],e,i).catch(o=>Y.error(o))}function tr(n,e,i,o){n=Pt(n),Fh(On,Bt[n.app.options.appId],e,i,o).catch(a=>Y.error(a))}const ti="@firebase/analytics",ei="0.10.21";function Xh(){yt(new at(Ks,(e,{options:i})=>{const o=e.getProvider("app").getImmediate(),a=e.getProvider("installations-internal").getImmediate();return Wh(o,a,i)},"PUBLIC")),yt(new at("analytics-internal",n,"PRIVATE")),rt(ti,ei),rt(ti,ei,"esm2020");function n(e){try{const i=e.getProvider(Ks).getImmediate();return{logEvent:(o,a,h)=>tr(i,o,a,h),setUserProperties:(o,a)=>Qi(i,o,a)}}catch(i){throw et.create("interop-component-reg-failed",{reason:i})}}}Xh();const fc=Object.freeze(Object.defineProperty({__proto__:null,logEvent:tr,setUserProperties:Qi},Symbol.toStringTag,{value:"Module"}));export{ga as A,pa as B,at as C,ua as D,ke as E,_t as F,fa as G,ma as H,aa as I,da as J,Ko as K,ci as L,la as M,uc as N,ac as O,cc as P,lc as Q,hc as R,Xo as S,fc as T,ca as W,ha as X,yt as _,Qh as a,Wr as b,Vo as c,Pt as d,oc as e,U as f,Yh as g,oi as h,Jh as i,Lr as j,hi as k,_n as l,Hr as m,Yo as n,fn as o,io as p,sc as q,rt as r,tc as s,nc as t,Zh as u,ic as v,rc as w,zr as x,Vr as y,ec as z};
