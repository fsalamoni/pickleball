import{_ as t,$ as c}from"./vendor-ui-M9eqwxUF.js";function n(...r){return t(c(r))}export{n as c};
