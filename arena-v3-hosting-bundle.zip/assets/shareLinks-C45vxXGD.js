function c(e){return String(e||"").replace(/\/+$/,"")}function a(e,i){const t=c(e),n=String(i||"").trim();return!t||!n?"":`${t}/p/${n}`}function s(e,i){const t=e||{},n=[];n.push(`🏓 ${String(t.name||"Torneio de Pickleball").trim()}`);const r=[t.city,t.state].map(o=>String(o||"").trim()).filter(Boolean).join(" / ");return r&&n.push(`📍 ${r}`),t.invite_code&&n.push(`🔑 Código de convite: ${t.invite_code}`),i&&n.push(`
Acompanhe ao vivo: ${i}`),n.push(`
via Pickleholics`),n.join(`
`)}function l(e){const i=String(e||"").trim();return i?`https://wa.me/?text=${encodeURIComponent(i)}`:""}function u({origin:e,tournament:i}){const t=a(e,i==null?void 0:i.id),n=s(i,t);return{url:t,text:n,whatsappUrl:l(n)}}export{l as a,u as b};
